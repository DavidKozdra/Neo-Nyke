const ACHIEVEMENTS = [
  { id: 'one_punch_man',  name: 'Won Punch Man',    desc: 'Deal 10,000 damage in one hit',         icon: '◉' },
  { id: 'the_avatar',     name: 'I Am the Avatar',  desc: 'Apply 4+ status effects in one run',    icon: '≋' },
  { id: 'rival_rumble',   name: 'Rival Rumble',     desc: 'Kill 100 rivals',                       icon: '⚔' },
  { id: 'gotta_meet_god', name: 'Gotta Meet God',   desc: 'Beat the game in under 5 minutes',      icon: '⚡' },
  { id: 'yeshua_is_king', name: 'Yeshua Is King',   desc: 'Heal 343 (7×7×7) HP total in one run',  icon: '✝' },
  { id: 'unkillable',     name: 'Unkillable',       desc: 'Beat the game without taking damage',   icon: '⛨' },
  { id: 'hoarder',        name: 'Hoarder',          desc: 'Hold 10 relics at once',                icon: '◈' },
  { id: 'glass_cannon',   name: 'Quartz Cannon',     desc: 'Win a run at 1 HP',                     icon: '✦' },
  { id: 'floor_muncher',  name: 'Floor Muncher',    desc: 'Reach floor 10',                        icon: '↟' },
  { id: 'overleveled',    name: 'Overleveled',      desc: 'Reach level 20 in a single run',        icon: '★' },
  { id: 'shopping_spree', name: 'Shopping Spree',   desc: 'Buy 5 items from shops in one run',     icon: '◎' },
  { id: 'loop_lord',      name: 'Loop Lord',        desc: 'Complete 3 loops in a single run',      icon: '♾' },
  { id: 'coin_goblin',    name: 'Coin Goblin',      desc: 'Accumulate 1,000 total coins',          icon: '◆' },
  { id: 'god_slayer',     name: 'God Slayer',        desc: 'Slay 10 gods',                          icon: '✟' },
  { id: 'extinction',     name: 'Extinction',       desc: 'Kill 1,000 enemies total',              icon: '☠' },
];

const ACHIEVEMENT_PROGRESS = {
  one_punch_man:  { key: 'bestHitDamage', target: 10000, label: 'Best hit' },
  the_avatar:     { key: 'statusesApplied', target: 4, label: 'Statuses this run' },
  rival_rumble:   { key: 'rival_kills', target: 100, label: 'Rivals slain' },
  yeshua_is_king: { key: 'runHealTotal', target: 343, label: 'Healing this run' },
  hoarder:        { key: 'maxRelicCount', target: 10, label: 'Relics held' },
  floor_muncher:  { key: 'maxFloorReached', target: 10, label: 'Highest floor' },
  overleveled:    { key: 'maxPlayerLevel', target: 20, label: 'Highest level' },
  shopping_spree: { key: 'runShopBuys', target: 5, label: 'Shop buys this run' },
  loop_lord:      { key: 'maxLoopIndex', target: 3, label: 'Loops this run' },
  coin_goblin:    { key: 'metaCoins', target: 1000, label: 'Coins banked' },
  god_slayer:     { key: 'gods_killed', target: 10, label: 'Gods slain' },
  extinction:     { key: 'enemies_killed', target: 1000, label: 'Enemies slain' },
};

window.ACHIEVEMENTS = ACHIEVEMENTS;
window.ACHIEVEMENT_PROGRESS = ACHIEVEMENT_PROGRESS;
