// viewport.js — Viewport rendering, lighting compositing.
export function drawWorldViewport(cam, vpX, vpW, vpH, vpY, pLabel, slot = null) {
    const isDying = Neo.gameState === 'dying';
    const slotDead = !!slot?.getDead?.();
    const _shakeOn = window.NeoSettings?.getAccess()?.screenShake !== false;
    const sX = _shakeOn && pLabel === 'P1' ? (Neo.nextRandom('fx') - 0.5) * Neo.shake * 2 : 0;
    const sY = _shakeOn && pLabel === 'P1' ? (Neo.nextRandom('fx') - 0.5) * Neo.shake * 2 : 0;
    Neo.ctx.save();
    Neo.ctx.beginPath();
    Neo.ctx.rect(vpX, vpY, vpW, vpH);
    Neo.ctx.clip();
    Neo.ctx.translate(vpX - cam.x + sX, vpY - cam.y + sY);
    Neo.drawFloor();
    Neo.drawRoomDecor();
    Neo.drawWorldProps();
    Neo.drawDeadBodies();
    Neo.drawChests();
    Neo.drawPickups();
    Neo.drawProjectiles();
    Neo.drawEnemyTelegraphs();
    Neo.drawEnemies();
    drawRoomCeilingMask();
    if (!isDying) {
      if (Neo.isMultiplayerMode()) {
        Neo.getActivePlayerSlots().forEach(drawSlot => {
          if (drawSlot.getDead()) return;
          if (drawSlot.id === 1) Neo.drawPlayer();
          else Neo.drawPlayerSlot(drawSlot);
        });
      } else {
        Neo.drawPlayer();
      }
    }
    if (!isDying) Neo.drawPlayerLaser();
    if (isDying && Neo.playerDeathAnim) Neo.drawPlayerCorpseAnim(Neo.playerDeathAnim);
    Neo.drawParticles();
    if (!isDying) Neo.drawLadderPrompt();
    if (!isDying) Neo.drawJesterPortalPrompt();
    // P-label in corner of each viewport (split only)
    if (Neo.isSplitScreen() && pLabel) {
      const slot = Neo.getActivePlayerSlots().find(candidate => candidate.label === pLabel);
      Neo.ctx.save();
      Neo.ctx.setTransform(1, 0, 0, 1, 0, 0);
      Neo.ctx.font = 'bold 11px monospace';
      Neo.ctx.textAlign = 'left';
      Neo.ctx.fillStyle = slot?.color || '#fff';
      Neo.ctx.fillText(pLabel, vpX + 8, vpY + 18);
      Neo.ctx.restore();
    }
    if (slotDead && pLabel) {
      Neo.ctx.save();
      Neo.ctx.setTransform(1, 0, 0, 1, 0, 0);
      Neo.ctx.fillStyle = 'rgba(0,0,0,.52)';
      Neo.ctx.fillRect(vpX, vpY, vpW, vpH);
      Neo.ctx.fillStyle = slot?.color || '#dfeeff';
      Neo.ctx.font = 'bold 24px monospace';
      Neo.ctx.textAlign = 'center';
      Neo.ctx.textBaseline = 'middle';
      Neo.ctx.fillText(`${pLabel} DOWN`, vpX + vpW / 2, vpY + vpH / 2);
      Neo.ctx.restore();
    }
    Neo.ctx.restore();
  }

export function getActiveRoomChamber(room, entity = Neo.player) {
    if (!room || !entity || !Array.isArray(room.layoutChambers) || room.layoutChambers.length === 0) return null;
    const containing = room.layoutChambers.find(chamber => (
      entity.x >= chamber.x - chamber.w / 2
      && entity.x <= chamber.x + chamber.w / 2
      && entity.y >= chamber.y - chamber.h / 2
      && entity.y <= chamber.y + chamber.h / 2
    ));
    if (containing) return containing;

    let nearest = room.layoutChambers[0];
    let bestDistance = Infinity;
    room.layoutChambers.forEach(chamber => {
      const distance = Math.hypot(entity.x - chamber.x, entity.y - chamber.y);
      if (distance < bestDistance) {
        bestDistance = distance;
        nearest = chamber;
      }
    });
    return nearest;
  }

export function withRoundedClipRect(rect, radius, drawFn) {
    if (!rect || typeof drawFn !== 'function') return;
    Neo.ctx.save();
    Neo.ctx.beginPath();
    Neo.ctx.roundRect(rect.x, rect.y, rect.w, rect.h, radius);
    Neo.ctx.clip();
    drawFn();
    Neo.ctx.restore();
  }

export function getRoomDarkness(room, lights) {
    const baseDarkness = room?.type === 'boss'
      ? Neo.LIGHTING_CONFIG.darkness.boss
      : room?.type === 'challenge'
        ? Neo.LIGHTING_CONFIG.darkness.challenge
        : Neo.LIGHTING_CONFIG.darkness.combat;
    const lightPressure = Math.min(1.2, lights.reduce((sum, light) => sum + light.strength, 0) / 14);
    return Math.max(0, baseDarkness - lightPressure * Neo.LIGHTING_CONFIG.darkness.lightRelief);
  }

export function createRoomDarknessGradient(alpha) {
    const darkness = Neo.ctx.createLinearGradient(0, 0, 0, Neo.ROOM_H);
    darkness.addColorStop(0, `rgba(10,14,22,${Math.min(0.28, alpha + 0.035)})`);
    darkness.addColorStop(0.5, `rgba(5,7,12,${alpha})`);
    darkness.addColorStop(1, `rgba(8,11,18,${Math.min(0.32, alpha + 0.05)})`);
    return darkness;
  }

export function carveSoftLight(x, y, innerRadius, outerRadius, strength = 1, clipRect = null) {
    const drawLight = () => {
      const gradient = Neo.ctx.createRadialGradient(x, y, innerRadius, x, y, outerRadius);
      gradient.addColorStop(0, 'rgba(0,0,0,1)');
      gradient.addColorStop(0.26, 'rgba(0,0,0,0.72)');
      gradient.addColorStop(0.66, 'rgba(0,0,0,0.22)');
      gradient.addColorStop(1, 'rgba(0,0,0,0)');
      Neo.ctx.globalAlpha = Neo.clamp(strength, 0, 1.12);
      Neo.ctx.fillStyle = gradient;
      Neo.ctx.fillRect(x - outerRadius, y - outerRadius, outerRadius * 2, outerRadius * 2);
    };

    if (clipRect) {
      withRoundedClipRect(clipRect, 32, drawLight);
      return;
    }
    drawLight();
  }

export function carvePlayerBeamLights() {
    if (Neo.laserActive) {
      const angle = Neo.laserMode === 'god_sweep'
        ? Neo.laserAngle
        : Math.atan2(Neo.mouse.worldY - Neo.player.y, Neo.mouse.worldX - Neo.player.x);
      const beamPath = Neo.buildRicochetBeamPath(Neo.player.x, Neo.player.y, angle, Neo.getPlayerBeamRange(Neo.laserMode, Neo.getEquippedMove('laser')), Neo.getPlayerBeamBounceCount(Neo.laserMode));
      Neo.carveBeamLight(beamPath, Neo.laserMode === 'god_sweep' ? 42 : Neo.laserMode === 'turtle_wave' ? 34 : 22, Neo.laserMode === 'god_sweep' ? 0.9 : 0.7);
      return;
    }

    if (Neo.getEquippedWeapon() !== 'lazer_glasses' || Neo.player.weaponBeamTime <= 0) return;
    const baseAngle = Math.atan2(Neo.mouse.worldY - Neo.player.y, Neo.mouse.worldX - Neo.player.x);
    [-0.2, 0.2].forEach(offset => {
      const beamPath = Neo.buildRicochetBeamPath(Neo.player.x, Neo.player.y, baseAngle + offset, 430, Neo.LAZER_GLASSES_BOUNCES);
      Neo.carveBeamLight(beamPath, 14, 0.46);
    });
  }

export function carveEnemyBeamLights() {
    Neo.enemies.forEach(enemy => {
      if (!enemy || Number(enemy.beamTime || 0) <= 0 || !Number.isFinite(enemy.beamAngle)) return;
      const beamPath = Neo.buildRicochetBeamPath(enemy.x, enemy.y, enemy.beamAngle, enemy.type === 'god' ? 620 : 460, Neo.getEnemyBeamBounceCount(enemy));
      Neo.carveBeamLight(beamPath, enemy.type === 'god' ? 36 : 18, enemy.type === 'god' ? 0.72 : 0.42);
    });
  }

export function lightTintWithAlpha(tint, alpha) {
    const match = /^rgba\((\s*\d+\s*,\s*\d+\s*,\s*\d+\s*),\s*[\d.]+\)$/.exec(tint);
    return match ? `rgba(${match[1]}, ${alpha})` : 'rgba(255,255,255,0)';
  }

export function drawLightBloom(lights) {
    Neo.ctx.globalCompositeOperation = 'lighter';
    lights.forEach(light => {
      if (!light.tint) return;
      const glow = Neo.ctx.createRadialGradient(light.x, light.y, Math.max(4, light.inner * 0.35), light.x, light.y, light.outer);
      glow.addColorStop(0, light.tint);
      glow.addColorStop(0.58, lightTintWithAlpha(light.tint, 0.02));
      glow.addColorStop(1, 'rgba(0,0,0,0)');
      Neo.ctx.fillStyle = glow;
      Neo.ctx.globalAlpha = Math.min(0.46, light.strength * 0.46);
      Neo.ctx.fillRect(light.x - light.outer, light.y - light.outer, light.outer * 2, light.outer * 2);
    });
  }

export function drawRoomCeilingMask() {
    const room = Neo.currentRoom;
    if (!room || Neo.LIGHTING_CONFIG.clearRoomTypes.has(room.type)) return;
    const lights = Neo.collectRoomLightSources(room);
    const darknessAlpha = getRoomDarkness(room, lights);
    if (darknessAlpha < Neo.LIGHTING_CONFIG.darkness.minVisible) return;

    Neo.ctx.save();
    Neo.ctx.fillStyle = createRoomDarknessGradient(darknessAlpha);
    Neo.ctx.fillRect(0, 0, Neo.ROOM_W, Neo.ROOM_H);
    Neo.ctx.globalCompositeOperation = 'destination-out';

    lights.forEach(light => {
      carveSoftLight(light.x, light.y, light.inner, light.outer, light.strength, null);
    });

    carvePlayerBeamLights();
    carveEnemyBeamLights();
    drawLightBloom(lights);
    Neo.ctx.restore();
  }

  // Expose on Neo
  Neo.drawWorldViewport = drawWorldViewport;
  Neo.getActiveRoomChamber = getActiveRoomChamber;
  Neo.withRoundedClipRect = withRoundedClipRect;
  Neo.getRoomDarkness = getRoomDarkness;
  Neo.createRoomDarknessGradient = createRoomDarknessGradient;
  Neo.carveSoftLight = carveSoftLight;
  Neo.carvePlayerBeamLights = carvePlayerBeamLights;
  Neo.carveEnemyBeamLights = carveEnemyBeamLights;
  Neo.lightTintWithAlpha = lightTintWithAlpha;
  Neo.drawLightBloom = drawLightBloom;
  Neo.drawRoomCeilingMask = drawRoomCeilingMask;
