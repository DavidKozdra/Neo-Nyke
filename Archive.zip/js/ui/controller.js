// controller.js — UI controller factory.

export function createUIController(view) {
    const UIManagerCtor = window.KozEngine?.UI?.uiManager?.UIManager || window.UIManager || null;
    const manager = typeof UIManagerCtor === 'function' ? new UIManagerCtor({ autoRuntimeInit: false }) : null;
    const DialogueManagerCtor = Neo.KozDialogueApi.TypewriterDialogueManager || window.TypewriterDialogueManager || null;
    const WorldSpeechBubbleCtor = Neo.KozWorldSpeechApi.WorldSpeechBubbleManager || window.WorldSpeechBubbleManager || null;
    const dialogueRuntime = typeof DialogueManagerCtor === 'function'
      ? new DialogueManagerCtor({
        gameStateManager: Neo.gameStateManager,
        defaultSpeaker: 'GOD',
        typeSpeed: 0.028,
        autoAdvanceDelay: 1.35,
        onOpen: () => Neo.clearGameplayInput(),
        onClose: () => Neo.clearGameplayInput(),
      })
      : null;
    const worldSpeechRuntime = typeof WorldSpeechBubbleCtor === 'function'
      ? new WorldSpeechBubbleCtor({ typeSpeed: 0.024, holdTime: 1.55, maxBubbles: 8 })
      : null;
    let menuBound = false;
    let restartBound = false;
    let activeState = 'menu';
    let hudUpdateHook = null;
    let challengePanelOpen = false;
    let runHistoryOpen = false;
    let runHistoryPage = 0;
    let runHistoryEntries = [];
    let runHistoryModeFilter = 'all';
    let selectedRunHistoryId = '';
    let activeRunHistoryTab = 'stats';
    let tutorialBannerCache = { open: null, text: null, hint: null, prevDisabled: null, nextDisabled: null };
    let objectiveEntriesCache = [];
    let objectiveTrackerVisible = false;
    let objectiveCompactMode = false;
    let objectiveExpanded = true;
    const runHistoryPageSize = 8;

    const LC = `<span class="lc-icon">◆</span>`;

    function ensureRunHistoryPanelCanOverlayGame() {
      if (!view.runHistoryPanel || view.runHistoryPanel.parentElement === document.body) return;
      document.body.appendChild(view.runHistoryPanel);
    }

    function getChallengeAccent(def) {
      const accent = String(def?.accent || '#8dd4ff').trim();
      return /^#[0-9a-f]{3,8}$/i.test(accent) ? accent : '#8dd4ff';
    }

    function getChallengeStatus(def, state) {
      if (!state.isUnlocked) return `LOCKED UNTIL ${def.unlockLoops} ${LC}`;
      if (state.isOwned) return state.isSelected ? 'ACTIVE THIS RUN' : 'OWNED';
      return `BUY ${def.cost} ${LC}`;
    }

    function renderChallengeButtonContent(def, state) {
      const status = getChallengeStatus(def, state);
      const accent = getChallengeAccent(def);
      return `
        <span class="challenge-btn__icon" style="--challenge-accent:${accent}">${Neo.escapeHtml(def.icon || '!')}</span>
        <span class="challenge-btn__content">
          <span class="challenge-btn__top">
            <b>${Neo.escapeHtml(def.name)}</b>
            <em>${status}</em>
          </span>
          <span class="challenge-btn__meta">${Neo.escapeHtml(def.theme || 'Challenge')}</span>
          <span class="challenge-btn__desc">${Neo.escapeHtml(def.description)}</span>
          <span class="challenge-btn__reward">${Neo.escapeHtml(def.reward || 'Challenge reward')}</span>
        </span>
      `;
    }

    function getMetaChallengeContext() {
      const loopCrystals = Math.max(0, Number(Neo.metaProgress?.loopCrystals || 0));
      const unlocked = typeof Neo.getUnlockedChallengeSet === 'function'
        ? Neo.getUnlockedChallengeSet()
        : new Set((Neo.CHALLENGE_ORDER || []).filter(key => loopCrystals >= Number(Neo.CHALLENGE_DEFS[key]?.unlockLoops || 0)));
      const owned = typeof Neo.getOwnedChallengeSet === 'function'
        ? Neo.getOwnedChallengeSet()
        : new Set(Neo.normalizeChallengeSelection?.(Neo.metaProgress?.unlockedChallenges || []) || []);
      const selected = new Set(Neo.normalizeChallengeSelection?.(Neo.selectedChallenges || []) || []);
      return { loopCrystals, unlocked, owned, selected };
    }

    function renderMetaChallengeCard(key, context) {
      const def = Neo.CHALLENGE_DEFS[key];
      if (!def) return '';
      const isUnlocked = context.unlocked.has(key);
      const isOwned = context.owned.has(key);
      const isSelected = context.selected.has(key);
      const status = getChallengeStatus(def, { isUnlocked, isOwned, isSelected });
      const className = [
        'meta-challenge-card',
        !isUnlocked ? 'meta-challenge-card--locked' : '',
        isOwned ? 'meta-challenge-card--owned' : '',
        isSelected ? 'meta-challenge-card--active' : '',
      ].filter(Boolean).join(' ');
      return `<div class="${className}" style="--challenge-accent:${getChallengeAccent(def)}">
        <span class="meta-challenge-card__icon">${Neo.escapeHtml(def.icon || '!')}</span>
        <div class="meta-challenge-card__body">
          <div class="meta-challenge-card__top">
            <b>${Neo.escapeHtml(def.name)}</b>
            <em>${status}</em>
          </div>
          <div class="meta-challenge-card__tags">
            <span>${Neo.escapeHtml(def.theme || 'Challenge')}</span>
            <span>${Neo.escapeHtml(def.reward || 'Challenge reward')}</span>
          </div>
          <p>${Neo.escapeHtml(def.description)}</p>
        </div>
      </div>`;
    }

    function renderMetaProgressionInfo() {
      const context = getMetaChallengeContext();
      const selectedCount = context.selected.size;
      const ownedCount = context.owned.size;
      const challengeBonus = Math.max(0, Math.round(Neo.getActiveChallengeCrystalBonusMultiplier?.() || 0));
      const ownedLegacy = new Set(Neo.metaProgress?.unlockedLegacy || []);
      const legacyOrder = Neo.LEGACY_ORDER || [];
      const legacyCards = legacyOrder.map(key => {
        const def = Neo.LEGACY_UPGRADES[key];
        if (!def) return '';
        const isOwned = ownedLegacy.has(key);
        const status = isOwned ? 'UNLOCKED' : context.loopCrystals >= def.cost ? `BUY ${def.cost} ${LC}` : `NEED ${def.cost} ${LC}`;
        return `<div class="meta-legacy-card${isOwned ? ' meta-legacy-card--owned' : ''}">
          <span class="meta-legacy-card__sigil lc-icon">◆</span>
          <div>
            <div class="meta-legacy-card__top">
              <b>${Neo.escapeHtml(def.name)}</b>
              <em>${status}</em>
            </div>
            <p>${Neo.escapeHtml(def.effect || def.description || '')}</p>
          </div>
        </div>`;
      }).join('');
      return `<div class="meta-info-layout">
        <div class="meta-info-summary">
          <div class="meta-info-summary__stat"><span>Loop Crystals</span><b>${context.loopCrystals}</b></div>
          <div class="meta-info-summary__stat"><span>Challenges Owned</span><b>${ownedCount}/${(Neo.CHALLENGE_ORDER || []).length}</b></div>
          <div class="meta-info-summary__stat"><span>Active Bonus</span><b>+${challengeBonus} ${LC}</b></div>
        </div>
        <section class="meta-info-section">
          <div class="meta-info-section__head">
            <h3>Challenge Shop</h3>
            <span>${selectedCount} active</span>
          </div>
          <div class="meta-challenge-grid">
            ${(Neo.CHALLENGE_ORDER || []).map(key => renderMetaChallengeCard(key, context)).join('')}
          </div>
        </section>
        <section class="meta-info-section">
          <div class="meta-info-section__head">
            <h3>Permanent Upgrades</h3>
            <span>${ownedLegacy.size}/${legacyOrder.length} unlocked</span>
          </div>
          <div class="meta-legacy-grid">${legacyCards}</div>
        </section>
      </div>`;
    }

    function isCompactObjectiveViewport() {
      return window.innerWidth <= 920;
    }

    function getObjectiveCompactSummary(entries = []) {
      if (!entries.length) return 'No objectives';
      const doneCount = entries.filter(entry => String(entry?.state || '') === 'done').length;
      const primary = entries.find(entry => String(entry?.state || '') !== 'done') || entries[0];
      const primaryText = String(primary?.text || '').trim();
      return `${doneCount}/${entries.length} done${primaryText ? ` • ${primaryText}` : ''}`;
    }

    function syncObjectiveTrackerCompactState() {
      if (!view.objectiveTracker) return;
      const compact = isCompactObjectiveViewport();
      if (compact !== objectiveCompactMode) {
        objectiveCompactMode = compact;
        objectiveExpanded = compact ? false : true;
      }

      if (!objectiveTrackerVisible) {
        view.objectiveTracker.classList.remove('objective-tracker--compact', 'objective-tracker--expanded');
        if (view.objectiveSummary) view.objectiveSummary.classList.add('hidden');
        if (view.objectiveList) view.objectiveList.classList.remove('hidden');
        if (view.objectiveToggle) {
          view.objectiveToggle.classList.add('hidden');
          view.objectiveToggle.setAttribute('aria-expanded', 'false');
        }
        return;
      }

      view.objectiveTracker.classList.toggle('objective-tracker--compact', objectiveCompactMode);
      view.objectiveTracker.classList.toggle('objective-tracker--expanded', !objectiveCompactMode || objectiveExpanded);
      if (view.objectiveToggle) {
        const showToggle = objectiveCompactMode;
        view.objectiveToggle.classList.toggle('hidden', !showToggle);
        view.objectiveToggle.setAttribute('aria-expanded', objectiveExpanded ? 'true' : 'false');
        view.objectiveToggle.textContent = objectiveExpanded ? 'Hide' : 'Show';
      }
      if (view.objectiveSummary) {
        const showSummary = objectiveCompactMode && !objectiveExpanded;
        view.objectiveSummary.classList.toggle('hidden', !showSummary);
        view.objectiveSummary.textContent = showSummary ? getObjectiveCompactSummary(objectiveEntriesCache) : '';
      }
      if (view.objectiveList) {
        view.objectiveList.classList.toggle('hidden', objectiveCompactMode && !objectiveExpanded);
      }
    }

    function setObjectiveLayout(layout) {
      if (!view.objectiveTracker) return;
      if (!layout) {
        view.objectiveTracker.style.removeProperty('top');
        view.objectiveTracker.style.removeProperty('right');
        view.objectiveTracker.style.removeProperty('width');
        view.objectiveTracker.style.removeProperty('max-height');
        view.objectiveTracker.style.removeProperty('overflow-y');
        return;
      }

      const margin = 4;
      const gap = window.innerWidth <= 920 ? 8 : 12;
      const trackerWidth = Math.round(Neo.clamp(window.innerWidth <= 920 ? 124 : 142, 108, window.innerWidth - margin * 2));
      let right = Math.round(Neo.clamp(window.innerWidth - layout.right, margin, window.innerWidth - trackerWidth - margin));
      let top = Math.max(margin, Math.round(layout.bottom + gap));
      let maxHeight = Math.floor(window.innerHeight - top - margin);

      // If there is not enough room below the minimap, place objectives left of it.
      if (maxHeight < 92) {
        top = Math.max(margin, Math.round(layout.top));
        right = Math.round(Neo.clamp(window.innerWidth - layout.left + gap, margin, window.innerWidth - trackerWidth - margin));
        maxHeight = Math.floor(window.innerHeight - top - margin);
      }

      view.objectiveTracker.style.top = `${top}px`;
      view.objectiveTracker.style.right = `${right}px`;
      view.objectiveTracker.style.width = `${trackerWidth}px`;
      view.objectiveTracker.style.maxHeight = `${Math.max(74, maxHeight)}px`;
      view.objectiveTracker.style.overflowY = 'auto';
      syncObjectiveTrackerCompactState();
    }

    if (view.objectiveToggle) {
      view.objectiveToggle.addEventListener('click', () => {
        if (!objectiveCompactMode || !objectiveTrackerVisible) return;
        objectiveExpanded = !objectiveExpanded;
        syncObjectiveTrackerCompactState();
      });
    }

    window.addEventListener('resize', () => {
      syncObjectiveTrackerCompactState();
    });

    function getVisibleRunHistoryEntries() {
      if (runHistoryModeFilter === 'all') return runHistoryEntries;
      return runHistoryEntries.filter(entry => Neo.normalizeGameMode(entry.mode) === runHistoryModeFilter);
    }

    function renderRunHistoryModeTabs() {
      view.runHistoryModeTabs.forEach(tab => {
        const tabMode = tab.dataset.mode || 'all';
        const active = tabMode === runHistoryModeFilter;
        tab.classList.toggle('active', active);
      });
    }

    function makeContainer(element, visibleDisplay = '') {
      return {
        show() {
          if (!element) return;
          element.classList.remove('hidden');
          element.style.display = visibleDisplay;
        },
        hide() {
          if (!element) return;
          element.classList.add('hidden');
          element.style.display = 'none';
        },
      };
    }

    function setSkillCard(name, current, max, active = false, charges = 0, maxCharges = 1) {
      const fill = name === 'melee' ? view.fillMelee
        : name === 'laser' ? view.fillLaser
          : name === 'smash' ? view.fillSmash
            : view.fillDash;
      const time = name === 'melee' ? view.timeMelee
        : name === 'laser' ? view.timeLaser
          : name === 'smash' ? view.timeSmash
            : view.timeDash;
      const card = view.actionCards[name];
      const ready = charges > 0 && !active;
      const partialCharge = charges < maxCharges && max > 0 ? Neo.clamp(1 - (current / max), 0, 1) : 0;
      const ratio = maxCharges <= 0 ? 0 : Neo.clamp((charges + partialCharge) / maxCharges, 0, 1);
      if (fill) fill.style.height = `${ratio * 100}%`;
      if (time) {
        time.textContent = active
          ? 'CAST'
          : maxCharges > 1 && charges > 0
            ? `${charges}/${maxCharges}`
            : ready
              ? 'READY'
              : current.toFixed(1);
      }
      if (card) card.classList.toggle('ready', ready);
    }

    function resolveDialoguePortraitKey(speaker = '') {
      const raw = String(speaker || '').trim();
      if (!raw) return Neo.getPlayerSpriteKey();
      const normalized = raw
        .toLowerCase()
        .replace(/[^a-z0-9 ]+/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
      if (!normalized) return Neo.getPlayerSpriteKey();

      const directKey = normalized.replace(/ /g, '_');
      if (Neo.SPRITE_DEFS[directKey]) return directKey;

      const noRival = normalized.replace(/^rival\s+/, '');
      const noRivalKey = noRival.replace(/ /g, '_');
      if (Neo.SPRITE_DEFS[noRivalKey]) return noRivalKey;

      if (normalized.includes('knight')) return 'thorn_knight';
      if (normalized.includes('knave')) return 'artificer_knave';
      if (normalized.includes('thorn')) return 'thorn_knight';
      if (normalized.includes('princess')) return 'princess';
      if (normalized.includes('metao')) return 'metao';
      if (normalized.includes('granialla')) return 'granialla';
      if (normalized.includes('mooggy')) return 'mooggy';
      if (normalized.includes('queen') && normalized.includes('cult')) return 'queen_cult';
      if (normalized.includes('bulk') && normalized.includes('golem')) return 'bulk_golem';
      if (normalized.includes('artificer')) return 'artificer_knave';
      if (normalized.includes('golem')) return 'golem';
      if (normalized.includes('god')) return 'god';
      if (normalized.includes('mirror')) return Neo.getPlayerSpriteKey();
      return 'hunter';
    }

    function renderDialogue() {
      if (!view.dialogueOverlay || !view.dialogueSpeaker || !view.dialogueText) return;
      const snapshot = dialogueRuntime?.getSnapshot?.() || { active: false, speaker: 'GOD', visibleText: '', isFullyTyped: false };
      view.dialogueOverlay.classList.toggle('hidden', !snapshot.active);
      view.dialogueOverlay.style.display = snapshot.active ? 'flex' : 'none';
      view.dialogueOverlay.setAttribute('aria-hidden', snapshot.active ? 'false' : 'true');
      if (!snapshot.active) {
        if (view.dialoguePortrait instanceof HTMLCanvasElement) {
          const portraitCtx = view.dialoguePortrait.getContext('2d');
          portraitCtx?.clearRect(0, 0, view.dialoguePortrait.width, view.dialoguePortrait.height);
        }
        return;
      }
      view.dialogueSpeaker.textContent = snapshot.speaker || 'GOD';
      view.dialogueText.textContent = snapshot.visibleText || '';
      if (view.dialoguePortrait instanceof HTMLCanvasElement) {
        const spriteKey = resolveDialoguePortraitKey(snapshot.speaker || '');
        Neo.drawSpriteToCanvas(view.dialoguePortrait, spriteKey, view.dialoguePortrait.width);
      }
      if (view.dialogueHint) {
        view.dialogueHint.textContent = snapshot.isFullyTyped ? 'ENTER TO CONTINUE' : 'ENTER TO SKIP';
      }
    }

    function renderEntityDialogue() {
      const layer = view.entityDialogueLayer;
      if (!layer) return;
      const bubbles = worldSpeechRuntime?.getActive?.() || [];
      layer.innerHTML = '';
      layer.classList.toggle('hidden', bubbles.length === 0);
      layer.style.display = bubbles.length ? 'block' : 'none';
      layer.setAttribute('aria-hidden', bubbles.length ? 'false' : 'true');
      if (!bubbles.length) return;
      const rect = Neo.canvas.getBoundingClientRect();
      const scaleX = rect.width / Neo.canvas.width;
      const scaleY = rect.height / Neo.canvas.height;
      bubbles.forEach((bubble) => {
        const screenX = (bubble.anchor.x - Neo.camera.x) * scaleX;
        const screenY = (bubble.anchor.y - Neo.camera.y - (bubble.offsetY || 48)) * scaleY;
        if (screenX < -140 || screenX > rect.width + 140 || screenY < -140 || screenY > rect.height + 80) return;
        const el = document.createElement('div');
        el.className = 'entity-dialogue-bubble';
        el.dataset.tone = bubble.tone || 'boss';
        el.style.left = `${screenX}px`;
        el.style.top = `${screenY}px`;
        if (bubble.speaker) {
          const name = document.createElement('div');
          name.className = 'entity-dialogue-name';
          name.textContent = bubble.speaker;
          el.appendChild(name);
        }
        const text = document.createElement('div');
        text.className = 'entity-dialogue-text';
        text.textContent = bubble.visibleText || '';
        el.appendChild(text);
        layer.appendChild(el);
      });
    }

    function fallbackState(state) {
      const show = state || 'menu';
      function setVisible(element, visible, displayValue = '') {
        if (!element) return;
        element.classList.toggle('hidden', !visible);
        element.style.display = visible ? displayValue : 'none';
      }
      view.start.classList.toggle('hidden',     show !== 'menu');
      view.charSelect?.classList.toggle('hidden', show !== 'charselect');
      view.dead.classList.toggle('hidden',      show !== 'dead');
      view.win.classList.toggle('hidden',       show !== 'win');
      const inventoryPause = !!Neo.inventoryPauseActive && !!view.invPanel && !view.invPanel.classList.contains('hidden');
      view.pause?.classList.toggle('hidden',    show !== 'pause' || inventoryPause);
      const inPlay = show === 'play' || show === 'pause' || show === 'dialogue' || show === 'dying';
      setVisible(view.hud, false, 'none');
      setVisible(view.actionBar, show === 'play' || show === 'pause' || show === 'dying', '');
      setVisible(view.hudLower, show === 'play' || show === 'pause', '');
      setVisible(view.adapterStatus, show === 'play', '');
      setVisible(view.playerStats, inPlay, '');
      setVisible(view.coinDisplay, inPlay, 'flex');
      setVisible(view.centerDisplay, inPlay, '');
      setVisible(view.objectiveTracker, inPlay, '');
      setVisible(view.dialogueOverlay, show === 'dialogue', 'flex');
      if (show !== 'play') setVisible(view.tutorialOverlay, false, 'flex');
      setVisible(view.entityDialogueLayer, inPlay, 'block');
      if (!inPlay && view.challengeStatus) {
        view.challengeStatus.classList.add('hidden');
        view.challengeStatus.setAttribute('aria-hidden', 'true');
      }
      if (show !== 'charselect') { setChallengePanelOpen(false); setLegacyPanelOpen(false); }
      if (show !== 'menu' && show !== 'pause') setRunHistoryOpen(false);
      if (show !== 'menu') { setAltModesPanelOpen(false); setSandboxPanelOpen(false); }
      setVisible(view.endlessHud, inPlay && Neo.gameMode === 'endless', 'flex');
      setVisible(view.practicePanel, inPlay && Neo.gameMode === 'practice' && show !== 'dying', 'block');
      const isBossRush = Neo.gameMode === 'boss_rush';
      if (view.timerFloorSlot) view.timerFloorSlot.style.display = isBossRush ? 'none' : '';
      if (view.timerBossSlot) view.timerBossSlot.style.display = isBossRush ? '' : 'none';
    }

    function setChallengePanelOpen(open) {
      challengePanelOpen = !!open;
      view.challengePanel?.classList.toggle('hidden', !challengePanelOpen);
      view.challengePanel?.setAttribute('aria-hidden', challengePanelOpen ? 'false' : 'true');
      view.challengeToggle?.setAttribute('aria-expanded', challengePanelOpen ? 'true' : 'false');
    }

    let legacyPanelOpen = false;
    function setLegacyPanelOpen(open) {
      legacyPanelOpen = !!open;
      view.legacyPanel?.classList.toggle('hidden', !legacyPanelOpen);
      view.legacyPanel?.setAttribute('aria-hidden', legacyPanelOpen ? 'false' : 'true');
      view.legacyToggle?.setAttribute('aria-expanded', legacyPanelOpen ? 'true' : 'false');
    }

    let runHistoryView = 'info';
    let activeInfoTab = 'items';

    function setRunHistoryOpen(open) {
      ensureRunHistoryPanelCanOverlayGame();
      runHistoryOpen = !!open;
      view.runHistoryPanel?.classList.toggle('hidden', !runHistoryOpen);
      view.runHistoryPanel?.setAttribute('aria-hidden', runHistoryOpen ? 'false' : 'true');
      if (view.runHistoryBtn) {
        view.runHistoryBtn.textContent = runHistoryOpen ? 'HIDE INFO' : 'INFO';
        view.runHistoryBtn.setAttribute('aria-expanded', runHistoryOpen ? 'true' : 'false');
      }
      if (open) setRunHistoryView('info');
    }

    function setRunHistoryView(view_) {
      runHistoryView = view_;
      const showAch     = view_ === 'achievements';
      const showProfile = view_ === 'profile';
      const showInfo    = view_ === 'info';
      const showBlog    = view_ === 'blog';
      const showRuns    = !showAch && !showProfile && !showInfo && !showBlog;
      view.runHistoryBody?.classList.toggle('hidden', !showRuns);
      view.runHistoryEmpty?.classList.toggle('hidden', true);
      view.achievementsList?.classList.toggle('hidden', !showAch);
      view.rhProfilePanel?.classList.toggle('hidden', !showProfile);
      view.rhInfoPanel?.classList.toggle('hidden', !showInfo);
      view.rhBlogPanel?.classList.toggle('hidden', !showBlog);
      const titles = { achievements: 'ACHIEVEMENTS', profile: 'PROFILE', runs: 'RUN HISTORY', info: 'INFO', blog: 'BLOG' };
      if (view.runHistoryPanelTitle) view.runHistoryPanelTitle.textContent = titles[view_] ?? 'INFO';
      view.runHistoryViewTabs?.forEach(t => t.classList.toggle('active', t.dataset.view === view_));
      if (showAch) populateAchievementsPanel();
      else if (showProfile) {
        if (view.rhBankCoins)  view.rhBankCoins.textContent  = Neo.metaProgress.coins ?? 0;
        if (view.rhLoopCount)  view.rhLoopCount.textContent  = Neo.metaProgress.loopCrystals ?? 0;
        if (view.rhBestFloor)  view.rhBestFloor.textContent  = Neo.metaProgress.bestFloor ?? 1;
        if (view.rhSaveState)  view.rhSaveState.textContent  = view.saveState?.textContent ?? '—';
      }
      else if (showInfo) populateInfoPanel(activeInfoTab);
      else if (showBlog) window.dispatchEvent(new CustomEvent('neo:blog-tab-opened'));
      else { view.runHistoryEmpty?.classList.toggle('hidden', Neo.runHistory.length > 0); renderRunHistoryPage(); }
    }

    const ENEMY_INFO = [
      { key: 'hunter',          label: 'Hunter',          boss: false, hp: 52,   dmg: 12, speed: 96,  attackStyle: 'melee',   immunities: [],                                    desc: 'Relentless tracker that closes in fast and slashes. Low HP but high pressure.' },
      { key: 'charger',         label: 'Charger',         boss: false, hp: 68,   dmg: 14, speed: 118, attackStyle: 'dash',    immunities: [],                                    desc: 'Winds up then dashes straight at the player for heavy knockback damage.' },
      { key: 'laser',           label: 'Laser Unit',      boss: false, hp: 52,   dmg: 12, speed: 96,  attackStyle: 'ranged',  immunities: [],                                    desc: 'Fires a precision beam from range. Keeps distance and punishes slow movement.' },
      { key: 'knave',           label: 'Knave',           boss: false, hp: 68,   dmg: 14, speed: 118, attackStyle: 'melee',   immunities: [],                                    desc: 'Fast melee fighter with erratic movement. Hard to read at close range.' },
      { key: 'sniper',          label: 'Sniper',          boss: false, hp: 58,   dmg: 12, speed: 104, attackStyle: 'ranged',  immunities: [],                                    desc: 'Long-range shooter that aims carefully before firing a high-damage shot.' },
      { key: 'machine_gunner',  label: 'Machine Gunner',  boss: false, hp: 96,   dmg: 8,  speed: 112, attackStyle: 'burst',   immunities: [],                                    desc: 'Sprays bullets in rapid bursts. Low per-shot damage but overwhelming volume.' },
      { key: 'golem',           label: 'Golem',           boss: false, hp: 132,  dmg: 18, speed: 70,  attackStyle: 'melee',   immunities: ['bleed'],                             desc: 'Slow stone tank immune to bleed. High HP and damage make it dangerous up close.' },
      { key: 'cult_mage',       label: 'Cult Mage',       boss: false, hp: 84,   dmg: 18, speed: 58,  attackStyle: 'ranged',  immunities: [],                                    desc: 'Slow-moving caster that hurls powerful projectiles. Prioritise from a distance.' },
      { key: 'cult_follower',   label: 'Cult Follower',   boss: false, hp: 34,   dmg: 8,  speed: 138, attackStyle: 'melee',   immunities: [],                                    desc: 'Frail but extremely fast swarmer. Dangerous in groups.' },
      { key: 'summoner',        label: 'Summoner',        boss: false, hp: 120,  dmg: 12, speed: 66,  attackStyle: 'summon',  immunities: [],                                    desc: 'Hangs back and periodically summons reinforcements. Kill it first.' },
      { key: 'shield_unit',     label: 'Shield Unit',     boss: false, hp: 210,  dmg: 10, speed: 52,  attackStyle: 'melee',   immunities: ['bleed'],                             desc: 'Heavy armoured tank with a barrier. Bleed immune. Can boost nearby allies.' },
      { key: 'healer',          label: 'Healer',          boss: false, hp: 150,  dmg: 10, speed: 64,  attackStyle: 'support', immunities: [],                                    desc: 'Restores HP to nearby enemies on a cooldown. Eliminate it before it undoes your damage.' },
      { key: 'boss_spawner',    label: 'Boss Spawner',    boss: false, hp: 300,  dmg: 8,  speed: 42,  attackStyle: 'summon',  immunities: ['bleed'],                             desc: 'Immobile spawner that releases enemies on a timer. Destroy it before the countdown ends.' },
      { key: 'bulk_golem',      label: 'Bulk Golem',      boss: true,  hp: 1280, dmg: 31, speed: 88,  attackStyle: 'melee',   immunities: ['bleed'],                             desc: 'Boss. Massive golem that splits into smaller golems at low HP. Ground-slam AOE attack.' },
      { key: 'artificer_knave', label: 'Artificer Knave', boss: true,  hp: 1880, dmg: 20, speed: 124, attackStyle: 'melee',   immunities: [],                                    desc: 'Boss. High-speed multi-phase fighter. Becomes more aggressive at each phase threshold.' },
      { key: 'queen_cult',      label: 'Queen Cult',      boss: true,  hp: 760,  dmg: 20, speed: 96,  attackStyle: 'summon',  immunities: [],                                    desc: 'Boss. Cult leader that summons followers and mages while striking with projectiles.' },
      { key: 'mirror_knight',   label: 'Mirror Champion', boss: true,  hp: 0,    dmg: 0,  speed: 0,   attackStyle: 'mirror',  immunities: [],                                    desc: 'Elite. Copies the player\'s equipped moves and items. The perfect counter to your build.' },
      { key: 'mooggy',          label: 'Mooggy',          boss: false, hp: 0,    dmg: 0,  speed: 0,   attackStyle: 'assassin',immunities: ['bleed'],                             desc: 'White and black assassin cat with a red aura. Mirrors your stats and items, then fires rapid bleed-stacking eye lasers.' },
      { key: 'god',             label: 'GOD',             boss: true,  hp: 920,  dmg: 18, speed: 108, attackStyle: 'beam',    immunities: ['bleed', 'fire', 'poison', 'dark'],   desc: 'Final boss. Multi-phase deity with beam sweeps, nova blasts, and judgement strikes. Immune to all status effects.' },
    ];

    function populateInfoPanel(tab) {
      activeInfoTab = tab;
      if (!view.rhInfoContent) return;
      view.rhInfoTabs?.forEach(t => t.classList.toggle('active', t.dataset.infoTab === tab));

      if (tab === 'items') {
        const rarityOrder = ['knight', 'wizard', 'god'];
        const sorted = Object.values(Neo.ITEM_DEFS).sort((a, b) => {
          const ri = rarityOrder.indexOf(a.rarity ?? a.category) - rarityOrder.indexOf(b.rarity ?? b.category);
          return ri !== 0 ? ri : (a.name || '').localeCompare(b.name || '');
        });
        view.rhInfoContent.innerHTML = `<div class="info-grid">${sorted.map(item => {
          const rarity = item.rarity || item.category || 'knight';
          return `<div class="info-card">
            <div class="info-card__header">
              <canvas class="info-card__icon" data-info-item="${item.key}" width="32" height="32"></canvas>
              <span class="info-card__name">${item.name}</span>
              <span class="info-card__tag info-card__tag--${rarity}">${rarity}</span>
            </div>
            <div class="info-card__desc">${item.description || ''}</div>
          </div>`;
        }).join('')}</div>`;
        view.rhInfoContent.querySelectorAll('[data-info-item]').forEach(el => {
          const item = Neo.ITEM_DEFS[el.dataset.infoItem];
          if (item) Neo.drawItemToastIcon(el, item);
        });

      } else if (tab === 'weapons') {
        const rarityOrder = ['knight', 'wizard', 'god'];
        const sorted = Object.values(Neo.WEAPON_DEFS).sort((a, b) => {
          const ri = rarityOrder.indexOf(a.rarity) - rarityOrder.indexOf(b.rarity);
          return ri !== 0 ? ri : (a.name || '').localeCompare(b.name || '');
        });
        view.rhInfoContent.innerHTML = `<div class="info-grid">${sorted.map(w => {
          return `<div class="info-card">
            <div class="info-card__header">
              <canvas class="info-card__icon" data-info-weapon="${w.key}" width="32" height="32"></canvas>
              <span class="info-card__name">${w.name}</span>
              <span class="info-card__tag info-card__tag--${w.rarity}">${w.rarity}</span>
            </div>
            <div class="info-card__desc">${w.description || ''}</div>
          </div>`;
        }).join('')}</div>`;
        view.rhInfoContent.querySelectorAll('[data-info-weapon]').forEach(el => {
          const w = Neo.WEAPON_DEFS[el.dataset.infoWeapon];
          if (w) Neo.drawItemToastIcon(el, w);
        });

      } else if (tab === 'moves') {
        const slotOrder = ['melee', 'laser', 'smash', 'dash'];
        const sorted = Object.values(Neo.MOVE_DEFS).sort((a, b) => {
          const si = slotOrder.indexOf(a.slot) - slotOrder.indexOf(b.slot);
          return si !== 0 ? si : (a.name || '').localeCompare(b.name || '');
        });
        view.rhInfoContent.innerHTML = `<div class="info-grid">${sorted.map(m => {
          const slotLabel = Neo.SLOT_LABELS[m.slot] || m.slot;
          const exclusive = m.exclusiveCharacter
            ? `<br><em style="color:rgba(200,200,255,0.5)">${Neo.titleCase(m.exclusiveCharacter.replace(/_/g, ' '))} only</em>`
            : '';
          return `<div class="info-card">
            <div class="info-card__header">
              <canvas class="info-card__icon" data-info-move="${m.key}" width="32" height="32"></canvas>
              <span class="info-card__name">${m.name}</span>
              <span class="info-card__tag info-card__tag--${m.slot}">${slotLabel}</span>
            </div>
            <div class="info-card__desc">${m.desc || ''}${exclusive}</div>
          </div>`;
        }).join('')}</div>`;
        view.rhInfoContent.querySelectorAll('[data-info-move]').forEach(el => {
          const move = Neo.MOVE_DEFS[el.dataset.infoMove];
          if (move) Neo.drawMoveToastIcon(el, move);
        });

      } else if (tab === 'enemies') {
        const attackStyleLabel = { melee: 'Melee', dash: 'Dash', ranged: 'Ranged', burst: 'Burst', summon: 'Summoner', support: 'Support', mirror: 'Mirror', assassin: 'Assassin', beam: 'Beam' };
        view.rhInfoContent.innerHTML = `
          <div class="info-enemy-layout">
            <div class="info-enemy-grid">${ENEMY_INFO.map(e => {
              const tagClass = e.boss ? 'info-enemy-card__tag--boss' : 'info-enemy-card__tag--normal';
              return `<div class="info-enemy-card" data-enemy-select="${e.key}" tabindex="0">
                <canvas class="info-enemy-card__sprite" data-info-enemy="${e.key}" width="52" height="52"></canvas>
                <div class="info-enemy-card__name">${e.label}</div>
                <span class="info-enemy-card__tag ${tagClass}">${e.boss ? 'Boss' : 'Enemy'}</span>
              </div>`;
            }).join('')}</div>
            <div class="info-enemy-detail hidden" id="infoEnemyDetail">
              <canvas class="info-enemy-detail__sprite" id="infoEnemySprite" width="80" height="80"></canvas>
              <div class="info-enemy-detail__name" id="infoEnemyName"></div>
              <div class="info-enemy-detail__tag-row" id="infoEnemyTagRow"></div>
              <div class="info-enemy-detail__stats" id="infoEnemyStats"></div>
              <div class="info-enemy-detail__desc" id="infoEnemyDesc"></div>
            </div>
          </div>`;
        view.rhInfoContent.querySelectorAll('[data-info-enemy]').forEach(el => {
          Neo.drawSpriteToCanvas(el, el.dataset.infoEnemy, 48);
        });
        const showEnemyDetail = (key) => {
          const e = ENEMY_INFO.find(x => x.key === key);
          if (!e) return;
          const detail = document.getElementById('infoEnemyDetail');
          const sprite = document.getElementById('infoEnemySprite');
          if (!detail || !sprite) return;
          detail.classList.remove('hidden');
          Neo.drawSpriteToCanvas(sprite, key, 76);
          document.getElementById('infoEnemyName').textContent = e.label;
          const isBoss = e.boss;
          const tagCls = isBoss ? 'info-enemy-card__tag--boss' : 'info-enemy-card__tag--normal';
          const styleLbl = attackStyleLabel[e.attackStyle] || e.attackStyle;
          document.getElementById('infoEnemyTagRow').innerHTML =
            `<span class="info-enemy-card__tag ${tagCls}">${isBoss ? 'Boss' : 'Enemy'}</span>` +
            `<span class="info-enemy-detail__style-tag">${styleLbl}</span>`;
          const immHtml = e.immunities.length
            ? e.immunities.map(im => `<span class="info-enemy-detail__imm">${im}</span>`).join('')
            : '<span class="info-enemy-detail__imm info-enemy-detail__imm--none">None</span>';
          const hpRow    = e.hp    ? `<div class="ied-stat"><span class="ied-stat__label">HP</span><span class="ied-stat__value">${e.hp}</span></div>` : '';
          const dmgRow   = e.dmg   ? `<div class="ied-stat"><span class="ied-stat__label">DMG</span><span class="ied-stat__value">${e.dmg}</span></div>` : '';
          const spdRow   = e.speed ? `<div class="ied-stat"><span class="ied-stat__label">SPD</span><span class="ied-stat__value">${e.speed}</span></div>` : '';
          document.getElementById('infoEnemyStats').innerHTML =
            `<div class="ied-stats-row">${hpRow}${dmgRow}${spdRow}</div>` +
            `<div class="ied-imm-row"><span class="ied-imm-label">Immune:</span>${immHtml}</div>`;
          document.getElementById('infoEnemyDesc').textContent = e.desc || '';
          view.rhInfoContent.querySelectorAll('[data-enemy-select]').forEach(card => {
            card.classList.toggle('info-enemy-card--selected', card.dataset.enemySelect === key);
          });
        };
        view.rhInfoContent.querySelectorAll('[data-enemy-select]').forEach(card => {
          card.addEventListener('click', () => showEnemyDetail(card.dataset.enemySelect));
          card.addEventListener('keydown', ev => { if (ev.key === 'Enter' || ev.key === ' ') showEnemyDetail(card.dataset.enemySelect); });
        });
        showEnemyDetail(ENEMY_INFO[0].key);

      } else if (tab === 'characters') {
        view.rhInfoContent.innerHTML = `<div class="info-char-grid">${Object.values(Neo.CHARACTER_DEFS).map(c => {
          const display = Neo.HERO_DISPLAY[c.key] || {};
          const statBars = (display.stats || []).map(s =>
            `<div class="info-char-stat">
              <span class="info-char-stat__label">${s.label}</span>
              <div class="info-char-stat__bar"><div class="info-char-stat__fill" style="width:${s.pct}%;background:${s.color}"></div></div>
            </div>`
          ).join('');
          const lockNote = c.unlock === 'godslain'
            ? '<div style="font-size:11px;color:rgba(255,110,80,0.75);margin-top:6px">Unlock: Slay GOD</div>'
            : '';
          return `<div class="info-char-card">
            <canvas class="info-char-card__sprite" data-info-char="${c.key}" width="64" height="64"></canvas>
            <div class="info-char-card__body">
              <div class="info-char-card__name">${c.name.toUpperCase()}</div>
              <div class="info-char-card__lore">${display.lore || ''}</div>
              <div class="info-char-card__stats">${statBars}</div>
              ${lockNote}
            </div>
          </div>`;
        }).join('')}</div>`;
        view.rhInfoContent.querySelectorAll('[data-info-char]').forEach(el => {
          Neo.drawSpriteToCanvas(el, el.dataset.infoChar, 60);
        });
      } else if (tab === 'meta') {
        view.rhInfoContent.innerHTML = renderMetaProgressionInfo();
      }
    }

    async function populateAchievementsPanel() {
      if (!view.achievementsList) return;
      view.achievementsList.innerHTML = '<div class="ach-loading">Loading…</div>';
      const progressSnapshot = typeof window.achievementManager?.getProgressSnapshot === 'function'
        ? await window.achievementManager.getProgressSnapshot()
        : {};
      progressSnapshot.metaCoins = Math.max(
        Math.max(0, Number(progressSnapshot.metaCoins) || 0),
        Math.max(0, Number(Neo.metaProgress?.coins) || 0)
      );
      const cards = await Promise.all((window.ACHIEVEMENTS || []).map(async a => {
        const unlocked = await window.achievementManager?.isUnlocked(a.id);
        const progressDef = window.ACHIEVEMENT_PROGRESS?.[a.id];
        const progressMarkup = !unlocked && progressDef
          ? renderAchievementProgress(progressDef, progressSnapshot)
          : '';
        return `<div class="ach-card${unlocked ? '' : ' ach-card--locked'}">
          <span class="ach-icon">${a.icon}</span>
          <div>
            <div class="ach-name">${a.name}</div>
            <div class="ach-desc">${a.desc}</div>
            ${progressMarkup}
            <div class="${unlocked ? 'ach-unlocked-badge' : 'ach-locked-badge'}">${unlocked ? '✓ Unlocked  +1 ◆' : '— Locked'}</div>
          </div>
        </div>`;
      }));
      view.achievementsList.innerHTML = cards.join('');
    }

    function renderAchievementProgress(progressDef, progressSnapshot) {
      const target = Math.max(1, Number(progressDef.target) || 1);
      const rawValue = Math.max(0, Number(progressSnapshot?.[progressDef.key]) || 0);
      const value = Math.min(rawValue, target);
      const percent = Math.max(0, Math.min(100, (value / target) * 100));
      return `<div class="ach-progress" aria-label="${Neo.escapeHtml(progressDef.label)} ${value} of ${target}">
        <div class="ach-progress__meta">
          <span>${Neo.escapeHtml(progressDef.label)}</span>
          <b>${value.toLocaleString()} / ${target.toLocaleString()}</b>
        </div>
        <div class="ach-progress__track"><i style="width:${percent.toFixed(2)}%"></i></div>
      </div>`;
    }

    function setAchievementsPanelOpen(open) {
      setRunHistoryOpen(open);
      if (open) setRunHistoryView('achievements');
    }

    function setAltModesPanelOpen(open) {
      view.altModesPanel?.classList.toggle('hidden', !open);
      view.altModesPanel?.setAttribute('aria-hidden', open ? 'false' : 'true');
      if (open) {
        const activeTab = view.altModesPanel?.querySelector('.altmodes-tab.active');
        if (activeTab?.dataset?.tab === 'competitive') initCompetitiveLeaderboard();
      }
    }

    // --- Competitive leaderboard ---
    let lbPage = 1;
    let lbLoading = false;
    let lbHasMore = true;
    let lbDebounceTimer = null;

    function initCompetitiveLeaderboard() {
      lbPage = 1;
      lbHasMore = true;
      const listEl = document.getElementById('competitiveLbList');
      const moreBtn = document.getElementById('competitiveLbMoreBtn');
      if (listEl) listEl.textContent = 'Loading...';
      if (moreBtn) moreBtn.style.display = 'none';
      debouncedLoadLb(true);
    }

    function debouncedLoadLb(immediate) {
      clearTimeout(lbDebounceTimer);
      lbDebounceTimer = setTimeout(loadLbPage, immediate ? 0 : 300);
    }

    function loadLbPage() {
      if (lbLoading || !lbHasMore) return;
      lbLoading = true;
      const statusEl = document.getElementById('competitiveLbStatus');
      if (statusEl) statusEl.textContent = 'Loading...';
      fetch(`${Neo.COMPETITIVE_SERVER_URL || 'http://localhost:3004'}/leadbyPage?page=${lbPage}`)
        .then(r => r.json())
        .then(data => {
          const listEl = document.getElementById('competitiveLbList');
          const moreBtn = document.getElementById('competitiveLbMoreBtn');
          if (!listEl) return;
          if (lbPage === 1) listEl.innerHTML = '';
          if (!data.data || data.data.length === 0) {
            if (lbPage === 1) listEl.textContent = 'No runs this week — be the first!';
          } else {
            const startRank = (lbPage - 1) * data.pageSize + 1;
            data.data.forEach((entry, i) => {
              const rank = startRank + i;
              const row = document.createElement('div');
              row.style.cssText = 'display:flex;gap:8px;align-items:baseline;border-bottom:1px solid rgba(255,255,255,0.06);padding:2px 0';
              row.innerHTML = `<span style="width:24px;text-align:right;color:#ffe566;font-weight:bold">${rank}.</span><span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escHtml(entry.name)}</span><span style="color:#aaa">Fl.${entry.floor}</span>`;
              listEl.appendChild(row);
            });
          }
          lbHasMore = !!data.hasMore;
          lbPage += 1;
          if (moreBtn) moreBtn.style.display = lbHasMore ? '' : 'none';
          if (statusEl) statusEl.textContent = data.totalEntries ? `${data.totalEntries} entries total` : '';
        })
        .catch(() => {
          const listEl = document.getElementById('competitiveLbList');
          if (listEl && lbPage === 1) listEl.textContent = 'Could not reach server.';
          if (statusEl) statusEl.textContent = '';
        })
        .finally(() => { lbLoading = false; });
    }

    function escHtml(str) {
      return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    }

    function setSandboxPanelOpen(open) {
      view.sandboxPanel?.classList.toggle('hidden', !open);
      view.sandboxPanel?.classList.toggle('sandbox-panel--open', open);
      view.sandboxPanel?.setAttribute('aria-hidden', open ? 'false' : 'true');
      view.altModesPanel?.classList.toggle('altmodes-panel--sandbox-open', open);
      view.altModeSandboxConfigBtn?.classList.toggle('is-active', open);
      document.getElementById('altModeSandboxCard')?.classList.toggle('altmode-card--configuring', open);
    }

    function renderRunHistoryDetail() {
      const visibleEntries = getVisibleRunHistoryEntries();
      const selected = visibleEntries.find(entry => entry.id === selectedRunHistoryId) || visibleEntries[0] || null;
      view.runHistoryTabs.forEach(tab => {
        const active = (tab.dataset.tab || 'stats') === activeRunHistoryTab;
        tab.classList.toggle('active', active);
      });
      if (!selected) {
        if (view.runHistoryHero) view.runHistoryHero.innerHTML = '';
        if (view.runHistoryTabPanel) view.runHistoryTabPanel.innerHTML = '';
        return;
      }
      if (view.runHistoryHero) {
        view.runHistoryHero.innerHTML = Neo.renderRunHistoryHero(selected);
        Neo.hydrateRunHistorySprites(view.runHistoryHero);
      }
      if (view.runHistoryTabPanel) {
        view.runHistoryTabPanel.innerHTML = Neo.renderRunHistoryTabContent(selected, activeRunHistoryTab);
        Neo.hydrateRunHistorySprites(view.runHistoryTabPanel);
      }
    }

    function renderRunHistoryPage() {
      renderRunHistoryModeTabs();
      const visibleEntries = getVisibleRunHistoryEntries();
      const totalPages = Math.max(1, Math.ceil(visibleEntries.length / runHistoryPageSize));
      runHistoryPage = Neo.clamp(runHistoryPage, 0, totalPages - 1);
      const start = runHistoryPage * runHistoryPageSize;
      const visiblePageEntries = visibleEntries.slice(start, start + runHistoryPageSize);
      if (!visibleEntries.some(entry => entry.id === selectedRunHistoryId)) {
        selectedRunHistoryId = visibleEntries[0]?.id || '';
      }
      if (view.runHistoryEmpty) view.runHistoryEmpty.classList.toggle('hidden', visibleEntries.length > 0);
      if (view.runHistoryList) {
        view.runHistoryList.innerHTML = visiblePageEntries.map(entry => Neo.renderRunHistoryListEntry(entry, entry.id === selectedRunHistoryId)).join('');
        view.runHistoryList.classList.toggle('hidden', visibleEntries.length === 0);
        view.runHistoryList.scrollTop = 0;
        Neo.hydrateRunHistorySprites(view.runHistoryList);
      }
      renderRunHistoryDetail();
      if (view.runHistoryPageLabel) {
        view.runHistoryPageLabel.textContent = visibleEntries.length
          ? `Page ${runHistoryPage + 1} / ${totalPages}`
          : 'Page 0 / 0';
      }
      if (view.runHistoryPrev) view.runHistoryPrev.disabled = runHistoryPage <= 0;
      if (view.runHistoryNext) view.runHistoryNext.disabled = runHistoryPage >= totalPages - 1 || visibleEntries.length === 0;
    }

    if (manager && typeof manager.registerScreen === 'function') {
      manager.registerScreen('coinDisplay', {
        create: () => makeContainer(view.coinDisplay, 'flex'),
        validStates: ['play', 'pause', 'dialogue'],
      });
      manager.registerScreen('centerDisplay', {
        create: () => makeContainer(view.centerDisplay, ''),
        validStates: ['play', 'pause', 'dialogue'],
      });
      manager.registerScreen('playerStats', {
        create: () => makeContainer(view.playerStats, ''),
        validStates: ['play', 'pause', 'dialogue'],
      });
      manager.registerScreen('actionBar', {
        create: () => makeContainer(view.actionBar, ''),
        validStates: ['play', 'pause'],
      });
      manager.registerScreen('hudLower', {
        create: () => makeContainer(view.hudLower, ''),
        validStates: ['play', 'pause'],
      });
      manager.registerScreen('adapterStatus', {
        create: () => makeContainer(view.adapterStatus, ''),
        validStates: ['play', 'pause'],
      });
      manager.registerScreen('dialogue', {
        create: () => makeContainer(view.dialogueOverlay, 'flex'),
        show: renderDialogue,
        update: renderDialogue,
        validStates: ['dialogue'],
      });
      manager.registerScreen('entityDialogue', {
        create: () => makeContainer(view.entityDialogueLayer, 'block'),
        show: renderEntityDialogue,
        update: renderEntityDialogue,
        validStates: ['play', 'pause', 'dialogue'],
      });
      manager.registerScreen('start', { create: () => makeContainer(view.start, ''), validStates: ['menu'] });
      manager.registerScreen('charSelect', { create: () => makeContainer(view.charSelect, ''), validStates: ['charselect'] });
      manager.registerScreen('dead', { create: () => makeContainer(view.dead, ''), validStates: ['dead'] });
      manager.registerScreen('win', { create: () => makeContainer(view.win, ''), validStates: ['win'] });
      manager.registerScreen('pause', { create: () => makeContainer(view.pause, ''), validStates: ['pause'] });
      if (Neo.gameStateManager && typeof manager.bindToStateManager === 'function') {
        manager.bindToStateManager(Neo.gameStateManager, { initialSync: true });
      }
    }

    if (Neo.gameStateManager && typeof Neo.gameStateManager.onChange === 'function') {
      Neo.gameStateManager.onChange((_from, to) => {
        activeState = to || 'menu';
        Neo.gameState = activeState;
        fallbackState(activeState);
      });
    }

    return {
      setState(state) {
        activeState = state || 'menu';
        if (Neo.gameStateManager && typeof Neo.gameStateManager.getState === 'function' && Neo.gameStateManager.getState() !== state) {
          Neo.gameStateManager.setState(state);
          return;
        }
        if (manager && typeof manager.onGameStateChange === 'function') manager.onGameStateChange(state);
        fallbackState(state);
      },
      setHudUpdateHook(hook) {
        hudUpdateHook = typeof hook === 'function' ? hook : null;
      },
      tick(dt = 0) {
        if (dialogueRuntime?.update) dialogueRuntime.update(dt);
        if (worldSpeechRuntime?.update) worldSpeechRuntime.update(dt);
        if (manager && typeof manager.updateAll === 'function') {
          manager.updateAll();
        } else {
          renderDialogue();
          renderEntityDialogue();
        }
        if ((activeState === 'play' || activeState === 'dying') && hudUpdateHook) hudUpdateHook();
      },
      bindMenuActions(handlers) {
        if (menuBound) return;
        ensureRunHistoryPanelCanOverlayGame();
        view.charButtons.forEach(button => {
          button.addEventListener('click', () => {
            handlers.onCharacterSelect(button.dataset.char || '', button);
          });
        });

        // Carousel prev/next arrows
        const carouselPrev = document.getElementById('carouselPrev');
        const carouselNext = document.getElementById('carouselNext');
        const charOrder = ['princess', 'thorn_knight', 'metao', 'granialla', 'mooggy'];
        function carouselStep(delta) {
          const currentIndex = charOrder.indexOf(handlers._getChosenCharacter ? handlers._getChosenCharacter() : 'princess');
          const nextIndex = currentIndex + delta;
          if (nextIndex >= 0 && nextIndex < charOrder.length) {
            const nextKey = charOrder[nextIndex];
            const btn = view.charButtons.find(b => b.dataset.char === nextKey);
            if (btn) handlers.onCharacterSelect(nextKey, btn);
          }
        }
        carouselPrev?.addEventListener('click', () => carouselStep(-1));
        carouselNext?.addEventListener('click', () => carouselStep(1));

        // Touch swipe on carousel viewport
        const viewport = document.querySelector('.char-carousel-viewport');
        if (viewport) {
          let touchStartX = 0;
          viewport.addEventListener('touchstart', e => { touchStartX = e.touches[0].clientX; }, { passive: true });
          viewport.addEventListener('touchend', e => {
            const dx = e.changedTouches[0].clientX - touchStartX;
            if (Math.abs(dx) > 40) carouselStep(dx < 0 ? 1 : -1);
          }, { passive: true });
        }

        view.difficultyButtons.forEach(button => {
          button.addEventListener('click', () => {
            handlers.onDifficultySelect(button.dataset.difficulty || '', button);
          });
        });

        // Sandbox Lab panel: visual "game hacking" controls moved to Alt Modes.
        function getSandboxEnemySpriteKey(type) {
          if (type === 'boss_spawner') return 'cult_follower';
          return type;
        }

        function hydrateSandboxTokenIcons() {
          view.sandboxEnemyList?.querySelectorAll('[data-sbox-enemy-icon]').forEach(el => {
            const key = String(el.dataset.sboxEnemyIcon || 'hunter');
            Neo.drawSpriteToCanvas(el, getSandboxEnemySpriteKey(key), 22);
          });
          view.sandboxItemList?.querySelectorAll('[data-sbox-item-icon]').forEach(el => {
            const itemKey = String(el.dataset.sboxItemIcon || '');
            const item = Neo.itemRegistry.get(itemKey) || Neo.ITEM_DEFS[itemKey];
            if (item) Neo.drawItemToastIcon(el, item);
          });
        }

        function renderSandboxTokenLists() {
          if (view.sandboxEnemyList) {
            view.sandboxEnemyList.innerHTML = Neo.SANDBOX_ENEMY_TYPES.map(type => {
              const active = Neo.sandboxSettings.allowedEnemies.includes(type);
              const label = Neo.getEnemyLabel(type);
              return `<button class="sandbox-token${active ? ' is-active' : ''}" data-sbox-enemy="${type}" type="button">`
                + `<canvas class="sandbox-token__icon" data-sbox-enemy-icon="${Neo.escapeHtml(type)}" width="28" height="28" aria-hidden="true"></canvas>`
                + `<span class="sandbox-token__label">${Neo.escapeHtml(label)}</span>`
                + `</button>`;
            }).join('');
          }
          if (view.sandboxItemList) {
            view.sandboxItemList.innerHTML = Neo.ITEM_KEYS.map(key => {
              const active = Neo.sandboxSettings.allowedItems.includes(key);
              const item = Neo.itemRegistry.get(key) || Neo.ITEM_DEFS[key];
              const label = item?.name || key.replace(/_/g, ' ');
              const rarity = String(item?.rarity || 'knight');
              return `<button class="sandbox-token sandbox-token--item sandbox-token--${Neo.escapeHtml(rarity)}${active ? ' is-active' : ''}" data-sbox-item="${key}" type="button">`
                + `<canvas class="sandbox-token__icon sandbox-token__icon--item" data-sbox-item-icon="${Neo.escapeHtml(key)}" width="26" height="26" aria-hidden="true"></canvas>`
                + `<span class="sandbox-token__label">${Neo.escapeHtml(label)}</span>`
                + `</button>`;
            }).join('');
          }
          hydrateSandboxTokenIcons();
        }

        function syncSandboxPanelFields() {
          document.querySelectorAll('#sandboxGrid .sandbox-row').forEach(row => {
            const param = row.dataset.sboxParam;
            if (!param) return;
            const slider = row.querySelector('.sandbox-slider');
            const numInput = row.querySelector('.sandbox-num');
            const value = Neo.sandboxSettings[param];
            if (slider && value !== undefined) slider.value = value;
            if (numInput && value !== undefined) numInput.value = value;
          });
          if (view.sandboxGodMode) view.sandboxGodMode.checked = !!Neo.sandboxSettings.godMode;
          renderSandboxTokenLists();
        }

        document.querySelectorAll('#sandboxGrid .sandbox-row').forEach(row => {
          const param = row.dataset.sboxParam;
          if (!param) return;
          const slider = row.querySelector('.sandbox-slider');
          const numInput = row.querySelector('.sandbox-num');
          const integerParam = param === 'startingCoins';
          function applyValue(raw) {
            const parsed = integerParam ? parseInt(raw, 10) : parseFloat(raw);
            const min = Number(slider?.min ?? 0);
            const max = Number(slider?.max ?? 1);
            const fallback = Number(slider?.value ?? 0);
            const clamped = Math.min(max, Math.max(min, Number.isFinite(parsed) ? parsed : fallback));
            const rounded = integerParam ? Math.round(clamped) : Math.round(clamped * 100) / 100;
            if (slider) slider.value = String(rounded);
            if (numInput) numInput.value = String(rounded);
            Neo.sandboxSettings[param] = rounded;
            Neo.persistMetaSoon();
          }
          slider?.addEventListener('input', () => applyValue(slider.value));
          numInput?.addEventListener('change', () => applyValue(numInput.value));
        });

        view.sandboxGodMode?.addEventListener('change', () => {
          Neo.sandboxSettings.godMode = !!view.sandboxGodMode?.checked;
          Neo.persistMetaSoon();
        });

        view.sandboxEnemyList?.addEventListener('click', event => {
          const btn = event.target instanceof Element ? event.target.closest('[data-sbox-enemy]') : null;
          if (!btn) return;
          const type = String(btn.dataset.sboxEnemy || '');
          if (!Neo.SANDBOX_ENEMY_TYPES.includes(type)) return;
          if (Neo.sandboxSettings.allowedEnemies.includes(type)) {
            Neo.sandboxSettings.allowedEnemies = Neo.sandboxSettings.allowedEnemies.filter(key => key !== type);
          } else {
            Neo.sandboxSettings.allowedEnemies = [...Neo.sandboxSettings.allowedEnemies, type];
          }
          Neo.sandboxSettings = Neo.normalizeSandboxSettings(Neo.sandboxSettings);
          syncSandboxPanelFields();
          Neo.persistMetaSoon();
        });

        view.sandboxItemList?.addEventListener('click', event => {
          const btn = event.target instanceof Element ? event.target.closest('[data-sbox-item]') : null;
          if (!btn) return;
          const key = String(btn.dataset.sboxItem || '');
          if (!Neo.ITEM_KEYS.includes(key)) return;
          if (Neo.sandboxSettings.allowedItems.includes(key)) {
            Neo.sandboxSettings.allowedItems = Neo.sandboxSettings.allowedItems.filter(itemKey => itemKey !== key);
          } else {
            Neo.sandboxSettings.allowedItems = [...Neo.sandboxSettings.allowedItems, key];
          }
          Neo.sandboxSettings = Neo.normalizeSandboxSettings(Neo.sandboxSettings);
          syncSandboxPanelFields();
          Neo.persistMetaSoon();
        });

        view.sandboxEnemiesAll?.addEventListener('click', () => {
          Neo.sandboxSettings.allowedEnemies = Neo.SANDBOX_ENEMY_TYPES.slice();
          syncSandboxPanelFields();
          Neo.persistMetaSoon();
        });
        view.sandboxEnemiesNone?.addEventListener('click', () => {
          Neo.sandboxSettings.allowedEnemies = [];
          Neo.sandboxSettings = Neo.normalizeSandboxSettings(Neo.sandboxSettings);
          syncSandboxPanelFields();
          Neo.persistMetaSoon();
        });
        view.sandboxItemsAll?.addEventListener('click', () => {
          Neo.sandboxSettings.allowedItems = Neo.ITEM_KEYS.slice();
          syncSandboxPanelFields();
          Neo.persistMetaSoon();
        });
        view.sandboxItemsNone?.addEventListener('click', () => {
          Neo.sandboxSettings.allowedItems = [];
          Neo.sandboxSettings = Neo.normalizeSandboxSettings(Neo.sandboxSettings);
          syncSandboxPanelFields();
          Neo.persistMetaSoon();
        });
        view.sandboxReset?.addEventListener('click', () => {
          Neo.sandboxSettings = Neo.normalizeSandboxSettings(Neo.SANDBOX_DEFAULT_SETTINGS);
          syncSandboxPanelFields();
          Neo.persistMetaSoon();
        });
        view.sandboxSaveClose?.addEventListener('click', handlers.onCloseSandboxConfig);
        view.sandboxClose?.addEventListener('click', handlers.onCloseSandboxConfig);
        view.sandboxPanelBackdrop?.addEventListener('click', handlers.onCloseSandboxConfig);
        syncSandboxPanelFields();

        view.challengeButtons.forEach(button => {
          button.addEventListener('click', () => {
            handlers.onChallengeSelect(button.dataset.challenge || '', button);
          });
        });
        view.challengeToggle?.addEventListener('click', handlers.onToggleChallenges);
        view.challengeClose?.addEventListener('click', () => setChallengePanelOpen(false));
        view.legacyButtons.forEach(button => {
          button.addEventListener('click', () => {
            handlers.onLegacySelect(button.dataset.legacy || '');
          });
        });
        view.legacyToggle?.addEventListener('click', handlers.onToggleLegacy);
        view.legacyClose?.addEventListener('click', () => setLegacyPanelOpen(false));
        view.runHistoryBtn?.addEventListener('click', handlers.onToggleRunHistory);
        view.runHistoryClose?.addEventListener('click', () => setRunHistoryOpen(false));
        view.runHistoryViewTabs?.forEach(tab => {
          tab.addEventListener('click', () => setRunHistoryView(tab.dataset.view || 'info'));
        });
        view.rhInfoTabs?.forEach(tab => {
          tab.addEventListener('click', () => populateInfoPanel(tab.dataset.infoTab || 'items'));
        });
        view.infoTutorialBtn?.addEventListener('click', () => {
          localStorage.setItem(Neo.REPLAY_TUTORIAL_KEY, '1');
          view.infoTutorialBtn.textContent = '✓ Set for next run';
          view.infoTutorialBtn.disabled = true;
          setTimeout(() => {
            if (view.infoTutorialBtn) {
              view.infoTutorialBtn.textContent = '▶ Tutorial';
              view.infoTutorialBtn.disabled = false;
            }
          }, 2200);
        });
        view.runHistoryPrev?.addEventListener('click', () => {
          runHistoryPage = Math.max(0, runHistoryPage - 1);
          renderRunHistoryPage();
        });
        view.runHistoryNext?.addEventListener('click', () => {
          runHistoryPage += 1;
          renderRunHistoryPage();
        });
        view.runHistoryList?.addEventListener('click', event => {
          const target = event.target instanceof Element ? event.target.closest('[data-run-id]') : null;
          if (!target) return;
          selectedRunHistoryId = target.dataset.runId || '';
          renderRunHistoryPage();
        });
        view.runHistoryHero?.addEventListener('click', event => {
          const btn = event.target instanceof Element ? event.target.closest('[data-rerun-id]') : null;
          if (!btn) return;
          handlers.onRerunFromHistory(btn.dataset.rerunId);
        });
        view.runHistoryTabs.forEach(tab => {
          tab.addEventListener('click', () => {
            activeRunHistoryTab = tab.dataset.tab || 'stats';
            renderRunHistoryDetail();
          });
        });
        view.runHistoryModeTabs.forEach(tab => {
          tab.addEventListener('click', () => {
            const mode = tab.dataset.mode || 'all';
            runHistoryModeFilter = mode === 'all' ? 'all' : Neo.normalizeGameMode(mode);
            runHistoryPage = 0;
            renderRunHistoryPage();
          });
        });
        view.go.addEventListener('click', handlers.onStartNew);
        view.seed.addEventListener('keydown', event => {
          if (event.key === 'Enter') handlers.onStartNew();
        });
        view.continueBtn?.addEventListener('click', handlers.onContinue);
        view.deleteRunBtn?.addEventListener('click', handlers.onDeleteRun);
        view.dialogueOverlay?.addEventListener('click', handlers.onAdvanceDialogue);
        view.tutorialPrevBtn?.addEventListener('click', handlers.onTutorialPrev);
        view.tutorialNextBtn?.addEventListener('click', handlers.onTutorialNext);
        view.tutorialSkipBtn?.addEventListener('click', handlers.onSkipTutorial);
        // New main-menu nav
        view.mainCompetitiveBtn?.addEventListener('click', () => {
          document.querySelectorAll('.altmodes-tab').forEach(t => t.classList.remove('active'));
          document.querySelectorAll('.altmodes-tab-panel').forEach(p => p.classList.add('hidden'));
          const compTab = document.querySelector('.altmodes-tab[data-tab="competitive"]');
          const compPanel = document.querySelector('.altmodes-tab-panel[data-panel="competitive"]');
          if (compTab) compTab.classList.add('active');
          if (compPanel) compPanel.classList.remove('hidden');
          setAltModesPanelOpen(true);
          initCompetitiveLeaderboard();
        });
        view.newRunBtn?.addEventListener('click', handlers.onOpenCharacterSelect);
        view.charBackBtn?.addEventListener('click', handlers.onCloseCharacterSelect);
        // Alt modes panel
        view.altModesBtn?.addEventListener('click', () => setAltModesPanelOpen(true));
        view.altModesClose?.addEventListener('click', () => setAltModesPanelOpen(false));
        view.altModeEndlessBtn?.addEventListener('click', () => {
          setAltModesPanelOpen(false);
          handlers.onOpenAltModeCharSelect('endless');
        });
        view.altModePracticeBtn?.addEventListener('click', () => {
          setAltModesPanelOpen(false);
          handlers.onOpenAltModeCharSelect('practice');
        });
        view.altModeBossRushBtn?.addEventListener('click', () => {
          setAltModesPanelOpen(false);
          handlers.onOpenAltModeCharSelect('boss_rush');
        });
        view.altModeCoopBtn?.addEventListener('click', () => {
          setAltModesPanelOpen(false);
          handlers.onOpenAltModeCharSelect('coop');
        });
        view.altModePvpBtn?.addEventListener('click', () => {
          setAltModesPanelOpen(false);
          handlers.onOpenAltModeCharSelect('pvp');
        });
        view.altModeCompetitiveBtn?.addEventListener('click', () => {
          setAltModesPanelOpen(false);
          handlers.onOpenAltModeCharSelect('competitive');
        });
        document.getElementById('competitiveLbMoreBtn')?.addEventListener('click', () => debouncedLoadLb(true));
        view.mpLobbyBack?.addEventListener('click', () => {
          Neo.closeMpLobby();
          setAltModesPanelOpen(true);
        });
        view.mpLobby1Btn?.addEventListener('click', () => {
          Neo.mpPlayerCount = 1;
          Neo.closeMpLobby();
          Neo.charSelectPhase = 'p1';
          Neo.setGameState('charselect');
          Neo.updateCharacterSelectionUI();
        });
        view.mpLobby2Btn?.addEventListener('click', () => {
          Neo.mpPlayerCount = 2;
          Neo.closeMpLobby();
          Neo.charSelectPhase = 'p1';
          Neo.setGameState('charselect');
          Neo.updateCharacterSelectionUI();
        });
        document.getElementById('mpLobby3Btn')?.addEventListener('click', () => {
          Neo.mpPlayerCount = 3;
          Neo.closeMpLobby();
          Neo.charSelectPhase = 'p1';
          Neo.setGameState('charselect');
          Neo.updateCharacterSelectionUI();
        });
        document.getElementById('mpLobby4Btn')?.addEventListener('click', () => {
          Neo.mpPlayerCount = 4;
          Neo.closeMpLobby();
          Neo.charSelectPhase = 'p1';
          Neo.setGameState('charselect');
          Neo.updateCharacterSelectionUI();
        });
        // Alt modes tabs
        document.querySelectorAll('.altmodes-tab').forEach(tab => {
          tab.addEventListener('click', () => {
            document.querySelectorAll('.altmodes-tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.altmodes-tab-panel').forEach(p => p.classList.add('hidden'));
            tab.classList.add('active');
            const panel = document.querySelector(`.altmodes-tab-panel[data-panel="${tab.dataset.tab}"]`);
            if (panel) panel.classList.remove('hidden');
            if (tab.dataset.tab === 'competitive') initCompetitiveLeaderboard();
          });
        });
        view.altModeSandboxConfigBtn?.addEventListener('click', handlers.onOpenSandboxConfig);
        view.altModeSandboxBtn?.addEventListener('click', () => {
          setAltModesPanelOpen(false);
          handlers.onStartSandbox();
        });
        // Practice panel toggle
        view.practicePanelToggle?.addEventListener('click', () => {
          view.practicePanelBody?.classList.toggle('hidden');
        });
        view.practiceMaxHpSlider?.addEventListener('input', () => {
          Neo.setPracticeMaxHp(view.practiceMaxHpSlider.value);
        });
        view.practiceMaxHpNum?.addEventListener('change', () => {
          Neo.setPracticeMaxHp(view.practiceMaxHpNum.value);
        });
        view.practiceClearBtn?.addEventListener('click', () => { Neo.enemies.length = 0; });
        view.practiceHealBtn?.addEventListener('click', () => {
          if (!Neo.player) return;
          Neo.player.hp = Neo.player.maxHp;
          Neo.updateHud();
        });
        view.practiceGiveItemBtn?.addEventListener('click', () => {
          if (!Neo.player) return;
          const key = Neo.rollItemDrop({ elite: true, stream: 'loot' });
          if (key) Neo.collectItem(key);
        });
        if (view.practiceEnemyGrid) Neo.buildPracticeEnemyGrid();
        menuBound = true;
      },
      bindRestartActions(actions) {
        if (restartBound) return;
        const defaultRestart = typeof actions === 'function' ? actions : actions?.onWinRestart;
        view.deadRestart?.addEventListener('click', defaultRestart);
        view.winRestart?.addEventListener('click', defaultRestart);
        view.deadActions?.forEach(button => {
          button.addEventListener('click', () => {
            const action = button.dataset.deadAction || 'retry-current';
            if (typeof actions === 'function') actions();
            else actions?.onDeadAction?.(action);
          });
        });
        view.winActions?.forEach(button => {
          button.addEventListener('click', () => {
            const action = button.dataset.winAction || 'new-seed';
            if (typeof actions === 'function') actions();
            else actions?.onWinAction?.(action);
          });
        });
        restartBound = true;
      },
      playDialogue(lines, options) {
        const started = dialogueRuntime?.start?.(lines, options);
        renderDialogue();
        return !!started;
      },
      advanceDialogue() {
        const advanced = dialogueRuntime?.advance?.();
        renderDialogue();
        return !!advanced;
      },
      isDialogueOpen() {
        return !!dialogueRuntime?.isOpen?.();
      },
      sayAtWorldAnchor(input) {
        const id = worldSpeechRuntime?.say?.(input);
        renderEntityDialogue();
        return id || null;
      },
      setSaveState(text) { view.saveState.textContent = text; },
      setChallengePanelOpen,
      setLegacyPanelOpen,
      setRunHistoryOpen,
      setSandboxPanelOpen,
      setAchievementsPanelOpen,
      setMenuMeta(coins, bestFloor, loopCrystals, saveState) {
        view.bankCoins.textContent = coins;
        view.bestFloor.textContent = bestFloor;
        if (view.loopCount) view.loopCount.textContent = loopCrystals;
        view.saveState.textContent = saveState;
      },
      setRunSummary(summary) {
        const hasRun = !!summary;
        // Main menu: show/hide Continue button
        view.continueBtn?.classList.toggle('hidden', !hasRun);
        view.runSummary.textContent = summary || '';
      },
      setRunHistory(entries) {
        runHistoryEntries = Neo.normalizeRunHistory(entries);
        runHistoryPage = 0;
        runHistoryModeFilter = 'all';
        selectedRunHistoryId = runHistoryEntries[0]?.id || '';
        activeRunHistoryTab = 'stats';
        renderRunHistoryPage();
      },
      updateCharacterSelection(unlocked, selected) {
        const CHAR_ORDER = ['princess', 'thorn_knight', 'metao', 'granialla', 'mooggy'];
        const CARD_W_ACTIVE = 270;
        const CARD_W_SIDE   = 200;
        const CARD_GAP      = 18;

        view.charButtons.forEach(button => {
          const itemKey = button.dataset.char;
          const hint = button.querySelector('small');
          const spriteCanvas = button.querySelector('[data-char-sprite]');
          const baseHint = hint?.dataset.base || hint?.textContent || '';
          if (hint && !hint.dataset.base) hint.dataset.base = baseHint;
          button.classList.toggle('locked', !unlocked.has(itemKey));
          button.classList.toggle('sel', selected === itemKey);
          button.disabled = !unlocked.has(itemKey);
          if (hint) {
            const mooggyProgress = Math.max(0, Math.min(3, Number(Neo.metaProgress?.mooggyDefeats || 0)));
            hint.textContent = unlocked.has(itemKey)
              ? baseHint
              : itemKey === 'mooggy'
                ? `beat Mooggy ${mooggyProgress}/3`
                : 'locked in bank';
          }
          if (spriteCanvas) {
            Neo.drawSpriteToCanvas(spriteCanvas, itemKey, 76, {
              alpha: unlocked.has(itemKey) ? 1 : 0.42,
            });
          }
        });

        // ── Carousel position ────────────────────────────────
        const track = document.getElementById('choose');
        const viewport = track?.parentElement;
        const activeIdx = CHAR_ORDER.indexOf(selected);
        if (track && viewport && activeIdx >= 0) {
          const viewW = viewport.offsetWidth || 440;
          const leftEdge = activeIdx * (CARD_W_SIDE + CARD_GAP);
          const tx = viewW / 2 - leftEdge - CARD_W_ACTIVE / 2;
          track.style.transform = `translateX(${tx}px)`;
        }

        // ── Arrow disabled state ─────────────────────────────
        const carouselPrev = document.getElementById('carouselPrev');
        const carouselNext = document.getElementById('carouselNext');
        const currentPos = CHAR_ORDER.indexOf(selected);
        if (carouselPrev) carouselPrev.disabled = currentPos <= 0;
        if (carouselNext) carouselNext.disabled = currentPos >= CHAR_ORDER.length - 1;

        // ── Go button: disable if selected character is locked ─
        const goBtn = document.getElementById('go');
        if (goBtn) goBtn.disabled = !unlocked.has(selected);

        // ── Hero detail panel ────────────────────────────────
        const detail = document.getElementById('heroDetail');
        const disp = Neo.HERO_DISPLAY[selected];
        if (detail && disp) {
          const statsHtml = disp.stats.map(s =>
            `<div class="char-stat-row"><span class="stat-label">${s.label}</span>` +
            `<div class="stat-bar"><div class="stat-fill" style="width:${s.pct}%;background:${s.color}"></div></div></div>`
          ).join('');
          const defaultMoves = Neo.getDefaultMovesForCharacter(selected);
          const kitNames = ['melee', 'laser', 'smash', 'dash']
            .map(slot => Neo.MOVE_DEFS[defaultMoves[slot]]?.name || defaultMoves[slot]);
          const skillsHtml = kitNames.map(s =>
            `<span class="hero-detail-skill-pip">${s}</span>`
          ).join('');
          detail.innerHTML =
            `<div class="hero-detail-portrait"><canvas id="heroDetailSprite" width="128" height="128" aria-hidden="true"></canvas></div>` +
            `<p class="hero-detail-lore">${disp.lore}</p>` +
            `<div class="hero-detail-stats"><div class="hero-detail-section-label">Stats</div>${statsHtml}</div>` +
            `<div class="hero-detail-skills"><div class="hero-detail-section-label">Kit</div>${skillsHtml}</div>`;
          Neo.drawSpriteToCanvas(document.getElementById('heroDetailSprite'), selected, 104);
        }
      },
      updateDifficultySelection(unlocked, selected, loopCrystals) {
        const selectedDef = Neo.getDifficultyDef(selected);
        view.difficultyButtons.forEach(button => {
          const key = button.dataset.difficulty === 'custom' ? 'custom' : Neo.normalizeDifficulty(button.dataset.difficulty || '');
          const def = Neo.getDifficultyDef(key);
          const isUnlocked = unlocked.has(key);
          button.classList.toggle('sel', selected === key);
          button.classList.toggle('locked', !isUnlocked);
          button.disabled = !isUnlocked;
          button.title = isUnlocked ? def.description : `Unlock at ${def.unlockLoops} Loop Crystals`;
        });
        if (view.difficultyHint) {
          view.difficultyHint.textContent = selectedDef.unlockLoops > 0 && !unlocked.has(selected)
              ? `Unlocks at ${selectedDef.unlockLoops} Loop Crystals. Current crystals: ${loopCrystals}`
              : `${selectedDef.description} Loop Crystals: ${loopCrystals}.`;
        }
      },
      updateChallengeSelection(unlocked, owned, selected, loopCrystals, bankCoins) {
        view.challengeButtons.forEach(button => {
          const key = button.dataset.challenge || '';
          const def = Neo.CHALLENGE_DEFS[key];
          if (!def) return;
          const isUnlocked = unlocked.has(key);
          const isOwned = owned.has(key);
          const isSelected = selected.includes(key);
          button.style.setProperty('--challenge-accent', getChallengeAccent(def));
          button.classList.toggle('locked', !isUnlocked);
          button.classList.toggle('purchased', isOwned);
          button.classList.toggle('sel', isSelected);
          button.disabled = !isUnlocked;
          button.title = !isUnlocked
            ? `Unlock at ${def.unlockLoops} Loop Crystals`
            : isOwned
              ? def.description
              : `${def.description} Cost: ${def.cost} Loop Crystals`;
          button.innerHTML = renderChallengeButtonContent(def, { isUnlocked, isOwned, isSelected });
        });
        if (view.challengeHint) {
          const activeCount = selected.length;
          const bonusCrystals = Math.max(0, Math.round(Neo.getActiveChallengeCrystalBonusMultiplier()));
          view.challengeHint.innerHTML = `${LC} ${loopCrystals} — Buy run types once, then toggle them. Active: ${activeCount}. Loop bonus: +${bonusCrystals} ${LC}.`;
        }
        if (activeInfoTab === 'meta' && view.rhInfoContent) view.rhInfoContent.innerHTML = renderMetaProgressionInfo();
      },
      updateLegacySelection(owned, loopCrystals) {
        view.legacyButtons.forEach(button => {
          const key = button.dataset.legacy || '';
          const def = Neo.LEGACY_UPGRADES[key];
          if (!def) return;
          const isOwned = owned.has(key);
          const canAfford = loopCrystals >= def.cost;
          button.classList.toggle('owned', isOwned);
          button.disabled = isOwned;
          const status = isOwned ? 'UNLOCKED' : canAfford ? `BUY ${def.cost} ${LC}` : `NEED ${def.cost} ${LC}`;
          button.innerHTML = `
            <span class="legacy-btn__top">
              <b>${Neo.escapeHtml(def.name)}</b>
              <em>${status}</em>
            </span>
            <span class="legacy-btn__desc">${Neo.escapeHtml(def.description)}</span>
            <span class="legacy-btn__effect">${Neo.escapeHtml(def.effect)}</span>
          `;
        });
        if (view.legacyHint) {
          const ownedCount = Neo.LEGACY_ORDER.filter(k => owned.has(k)).length;
          view.legacyHint.innerHTML = `${LC} ${loopCrystals} — Unlocked: ${ownedCount} / ${Neo.LEGACY_ORDER.length}. Upgrades are permanent and apply to all future runs.`;
        }
        if (activeInfoTab === 'meta' && view.rhInfoContent) view.rhInfoContent.innerHTML = renderMetaProgressionInfo();
      },
      setItemStatus(items) {
        Neo.ITEM_KEYS.forEach(key => {
          const count = Number(items[key] || 0);
          view.itemSlots[key]?.classList.toggle('on', count > 0);
          if (view.itemCounts[key]) view.itemCounts[key].textContent = String(count);
        });
      },
      setObjective(text) { view.objective.textContent = text; },
      setTutorialBanner(text, visible) {
        const open = !!visible && !!text && Neo.gameState === 'play';
        if (view.tutorialOverlay && tutorialBannerCache.open !== open) {
          view.tutorialOverlay.classList.toggle('hidden', !open);
          view.tutorialOverlay.setAttribute('aria-hidden', open ? 'false' : 'true');
          view.tutorialOverlay.style.display = open ? 'flex' : 'none';
          tutorialBannerCache.open = open;
        }
        if (view.tutorialSpeaker && open && view.tutorialSpeaker.textContent !== 'TUTORIAL') {
          view.tutorialSpeaker.textContent = 'TUTORIAL';
        }
        const nextText = open ? String(text || '') : '';
        if (view.tutorialText && tutorialBannerCache.text !== nextText) {
          view.tutorialText.textContent = nextText;
          tutorialBannerCache.text = nextText;
        }
        const nextHint = open ? 'Use Previous/Next. Press K or click Skip Tutorial' : '';
        if (view.tutorialHint && tutorialBannerCache.hint !== nextHint) {
          view.tutorialHint.textContent = nextHint;
          tutorialBannerCache.hint = nextHint;
        }
        const stepOrder = Neo.getTutorialStepOrder();
        const stepIndex = stepOrder.indexOf(Neo.tutorialState?.step || 'move');
        const prevDisabled = !open || stepIndex <= 0;
        const nextDisabled = !open || stepIndex < 0 || stepIndex >= (stepOrder.length - 1);
        if (view.tutorialPrevBtn && tutorialBannerCache.prevDisabled !== prevDisabled) {
          view.tutorialPrevBtn.disabled = prevDisabled;
          tutorialBannerCache.prevDisabled = prevDisabled;
        }
        if (view.tutorialNextBtn && tutorialBannerCache.nextDisabled !== nextDisabled) {
          view.tutorialNextBtn.disabled = nextDisabled;
          tutorialBannerCache.nextDisabled = nextDisabled;
        }
      },
      setObjectiveList(roomLabel, entries = []) {
        if (!view.objectiveTracker || !view.objectiveList) return;
        const visible = Neo.gameState === 'play' && entries.length > 0;
        objectiveTrackerVisible = visible;
        objectiveEntriesCache = Array.isArray(entries) ? entries.slice() : [];
        view.objectiveTracker.classList.toggle('hidden', !visible);
        view.objectiveTracker.setAttribute('aria-hidden', visible ? 'false' : 'true');
        if (view.objectiveRoomLabel) view.objectiveRoomLabel.textContent = String(roomLabel || 'ROOM').toUpperCase();
        view.objectiveList.innerHTML = entries.map(entry => (
          `<li data-state="${Neo.escapeHtml(entry.state || 'todo')}">${Neo.escapeHtml(entry.text || '')}</li>`
        )).join('');
        syncObjectiveTrackerCompactState();
      },
      setObjectiveLayout,
      setHudValues(payload) {
        view.fl.textContent = payload.floor;
        view.lv.textContent = payload.level;
        view.xp.textContent = payload.xpText;
        if (view.gameTime) view.gameTime.textContent = payload.gameTime;
        if (view.difficultyLabel) view.difficultyLabel.textContent = String(payload.difficultyName || '').toUpperCase();
        else if (view.difficultyDisplay) view.difficultyDisplay.textContent = String(payload.difficultyName || '').toUpperCase();
        if (view.itemRarityCounts && payload.itemRarityCounts) {
          const white = view.itemRarityCounts.querySelector('.rarity-count--white');
          const purple = view.itemRarityCounts.querySelector('.rarity-count--purple');
          const red = view.itemRarityCounts.querySelector('.rarity-count--red');
          if (white) white.textContent = String(payload.itemRarityCounts.white || 0);
          if (purple) purple.textContent = String(payload.itemRarityCounts.purple || 0);
          if (red) red.textContent = String(payload.itemRarityCounts.red || 0);
        }
        view.coins.textContent = payload.coins;
        view.charName.textContent = payload.character;
        view.hpFill.style.width = `${Math.max(0, payload.hp / payload.maxHp) * 100}%`;
        view.hpTxt.textContent = Math.ceil(payload.hp);
        if (view.cdM) view.cdM.textContent = payload.meleeCd.toFixed(1);
        if (view.cdL) view.cdL.textContent = payload.laserCd.toFixed(1);
        if (view.cdS) view.cdS.textContent = payload.smashCd.toFixed(1);
        if (view.cdD) view.cdD.textContent = payload.dashCd.toFixed(1);
        if (payload.skills) {
          const melee = payload.skills.melee;
          const laser = payload.skills.laser;
          const smash = payload.skills.smash;
          const dash = payload.skills.dash;
          if (melee) setSkillCard('melee', melee.current, melee.max, !!melee.active, melee.charges, melee.maxCharges);
          if (laser) setSkillCard('laser', laser.current, laser.max, !!laser.active, laser.charges, laser.maxCharges);
          if (smash) setSkillCard('smash', smash.current, smash.max, !!smash.active, smash.charges, smash.maxCharges);
          if (dash) setSkillCard('dash', dash.current, dash.max, !!dash.active, dash.charges, dash.maxCharges);
        }
      },
      setDeadScreen(entry) {
        const fmt = (n) => String(n ?? '—');
        const fmtTime = (s) => {
          const m = Math.floor(s / 60);
          const sec = Math.floor(s % 60);
          return `${m}:${sec.toString().padStart(2, '0')}`;
        };
        if (view.deadKillerCanvas) {
          Neo.drawSpriteToCanvas(view.deadKillerCanvas, Neo.resolveKillerSprite(entry.killerKey || ''), 120);
        }
        if (view.deadKillerName) view.deadKillerName.textContent = entry.killedBy || 'Unknown';
        if (view.deadFloor) view.deadFloor.textContent = `${fmt(entry.floor)}/10`;
        if (view.deadLevel) view.deadLevel.textContent = fmt(entry.level);
        if (view.deadKills) view.deadKills.textContent = fmt(entry.kills);
        if (view.deadTime) view.deadTime.textContent = fmtTime(entry.elapsedSeconds || 0);
        if (view.deadCoins) view.deadCoins.textContent = fmt(entry.coins);
        if (view.deadDifficulty) view.deadDifficulty.textContent = (entry.difficultyName || entry.difficulty || '—').toUpperCase();
        const reviveButton = view.deadActions?.find(button => button.dataset.deadAction === 'revive');
        if (reviveButton) {
          const cost = Neo.getReviveCost();
          const crystals = Number(Neo.metaProgress.loopCrystals || 0);
          reviveButton.innerHTML = `REVIVE ${cost} ${LC}`;
          reviveButton.disabled = crystals < cost;
          reviveButton.title = crystals < cost ? `Need ${cost} Loop Crystal${cost === 1 ? '' : 's'}` : `Spend ${cost} Loop Crystal${cost === 1 ? '' : 's'} to revive`;
        }

        // ── Records row ────────────────────────────────────────────────────
        if (view.deadRecords) {
          const nr = entry._newRecords || {};
          const records = Neo.deriveRunRecords(Neo.runHistory, Neo.metaProgress);
          const bests = [
            { label: 'FLOOR',  val: `${records.floor}/10`,         isNew: nr.floor },
            { label: 'KILLS',  val: fmt(records.kills),            isNew: nr.kills },
            { label: 'LEVEL',  val: fmt(records.level),            isNew: nr.level },
            { label: 'TIME',   val: fmtTime(records.time),         isNew: nr.time  },
            { label: 'COINS',  val: fmt(records.coins),            isNew: nr.coins },
          ];
          view.deadRecords.innerHTML = bests.map(b =>
            `<div class="dead-record${b.isNew ? ' dead-record--new' : ''}">
              <span class="dead-record-label">${b.label}</span>
              <span class="dead-record-val">${b.val}</span>
              ${b.isNew ? '<span class="dead-record-badge">NEW</span>' : ''}
            </div>`
          ).join('');
        }

        // ── Item icon cards with pagination ────────────────────────────────
        if (view.deadItems) {
          const items = Array.isArray(entry.items) ? entry.items : [];
          const PAGE_SIZE = 5;
          let itemPage = 0;
          const totalPages = Math.max(1, Math.ceil(items.length / PAGE_SIZE));

          const renderItemPage = () => {
            view.deadItems.innerHTML = '';
            if (items.length === 0) {
              view.deadItems.innerHTML = '<span class="dead-items-empty">None</span>';
            } else {
              const slice = items.slice(itemPage * PAGE_SIZE, itemPage * PAGE_SIZE + PAGE_SIZE);
              slice.forEach(item => {
                const itemDef = Neo.ITEM_DEFS[item.key] || {};
                const rc = { knight: 'knight', white: 'knight', wizard: 'wizard', purple: 'wizard', god: 'god' }[item.rarity] || 'knight';
                const card = document.createElement('div');
                card.className = `dead-item-card dead-item-card--${rc}`;
                const cnv = document.createElement('canvas');
                cnv.width = 32;
                cnv.height = 32;
                cnv.className = 'dead-item-icon';
                Neo.drawItemToastIcon(cnv, { ...itemDef, key: item.key, rarity: item.rarity, color: itemDef.color, accent: itemDef.accent });
                const label = document.createElement('span');
                label.className = 'dead-item-name';
                label.textContent = item.count > 1 ? `${item.name} ×${item.count}` : item.name;
                card.appendChild(cnv);
                card.appendChild(label);
                view.deadItems.appendChild(card);
              });
            }
            if (view.deadItemsPage) view.deadItemsPage.textContent = totalPages > 1 ? `${itemPage + 1}/${totalPages}` : '';
            if (view.deadItemsPrev) view.deadItemsPrev.disabled = itemPage <= 0;
            if (view.deadItemsNext) view.deadItemsNext.disabled = itemPage >= totalPages - 1;
            if (view.deadItemsPrev) view.deadItemsPrev.classList.toggle('hidden', totalPages <= 1);
            if (view.deadItemsNext) view.deadItemsNext.classList.toggle('hidden', totalPages <= 1);
            if (view.deadItemsPage) view.deadItemsPage.classList.toggle('hidden', totalPages <= 1);
          };

          if (view.deadItemsPrev) {
            view.deadItemsPrev.onclick = () => { itemPage = Math.max(0, itemPage - 1); renderItemPage(); };
          }
          if (view.deadItemsNext) {
            view.deadItemsNext.onclick = () => { itemPage = Math.min(totalPages - 1, itemPage + 1); renderItemPage(); };
          }
          renderItemPage();
        }
      },
      setWinInfo(text) { view.winInfo.textContent = text; },
    };
  }

Neo.createUIController = createUIController;
